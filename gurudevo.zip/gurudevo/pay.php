<?php 
session_start();
error_reporting(0);
include('db/conn.php');
if(isset($_POST['submit'])){
		if(!empty($_SESSION['cart'])){
		foreach($_POST['quantity'] as $key => $val){
			if($val==0){
				unset($_SESSION['cart'][$key]);
			}else{
				$_SESSION['cart'][$key]['quantity']=$val;

			}
		}
			echo "<script>alert('Your Cart hasbeen Updated');</script>";
		}
	}

?>

<?php include 'header.php' ?>
<!-- ============================================== HEADER : END ============================================== -->
<div class="clearfix"></div>
<div class="breadcrumb">
	<div class="container">
		<div class="breadcrumb-inner">
			<ul class="list-inline list-unstyled">
				<li><a href="#">Home</a> <i class="fa fa-angle-right"></i></li>
				<li class='active'>Payment Gateway</li> 
			</ul>
		</div><!-- /.breadcrumb-inner -->
	</div><!-- /.container -->
</div><!-- /.breadcrumb -->
<?php
if(!empty($_SESSION['cart'])){
	?>
	
 <?php
 $pdtid=array();
    $sql = "SELECT * FROM products WHERE id IN(";
			foreach($_SESSION['cart'] as $id => $value){
			$sql .=$id. ",";
			}
			$sql=substr($sql,0,-1) . ") ORDER BY id ASC";
			$query = mysqli_query($con,$sql);
			$totalprice=0;
			$totalqunty=0;
			if(!empty($query)){
			while($row = mysqli_fetch_array($query)){
				$quantity=$_SESSION['cart'][$row['id']]['quantity'];
				$subtotal= $_SESSION['cart'][$row['id']]['quantity']*$row['productPrice']+$row['shippingCharge'];
				$totalprice += $subtotal*$row['razorpay_multiply'];
				$_SESSION['qnty']=$totalqunty+=$quantity;

				array_push($pdtid,$row['id']);
//print_r($_SESSION['pid'])=$pdtid;exit;
	?>

					


				<?php } }
$_SESSION['pid']=$pdtid;
				?>
			<div class="container text-center">
				<div class="row">
                <h3 class="text-center">Choose Your Payment Method</h3>
                    <div class="col-md-6">
                    <button  class="btn btn-primary"> COD </button>
                    </div>
                    <div class="col-md-6">
                    <button id="rzp-button1" type="submit" name="ordersubmit" class="btn btn-primary">Pay Now</button>


                            <script>
                            $order  = $client->order->create([
                            'receipt'         => 'order_rcptid_11',
                            'amount'          => <?php echo $_SESSION['tp']="$totalprice". ".00"; ?>, // amount in the smallest currency unit
                            'currency'        => 'INR',// <a href="/docs/payment-gateway/payments/international-payments/#supported-currencies" target="_blank">See the list of supported currencies</a>.)
                            ]);
                            </script>
                            <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
                            <script>
                            var options = {
                                "key": "rzp_live_X2GeCFxdcx17sg", // Enter the Key ID generated from the Dashboard
                                "secret": "Q86RAuMPqofJ11sN8lj0u7Le",
                                "amount": "<?php echo $_SESSION['tp']="$totalprice". ".00"; ?>", // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
                                "currency": "INR",
                                "name": "Acme Corp",
                                "description": "Test Transaction",
                                "image": "http://gurudevo.in/images/logo2.png",
                                "order_id": "<?php echo $row['oid'] ?>", //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
                                "callback_url": "https://eneqd3r9zrjok.x.pipedream.net/",
                                "prefill": {
                                    "name": "Gautam Ishan",
                                    "email": "gautam_ishan2802@yahoo.com",
                                    "contact": "9999999999"
                                },
                                "notes": {
                                    "address": "Razorpay Corporate Office"
                                },
                                "theme": {
                                    "color": "#F37254"
                                }
                            };
                            var rzp1 = new Razorpay(options);
                            rzp1.on('payment.failed', function (response){
                                    alert(response.error.code);
                                    alert(response.error.description);
                                    alert(response.error.source);
                                    alert(response.error.step);
                                    alert(response.error.reason);
                                    alert(response.error.metadata);
                            });
                            document.getElementById('rzp-button1').onclick = function(e){
                                rzp1.open();
                                e.preventDefault();
                            }
                            </script>
                    </div>
                </div>
                </div>

                   
								
	
	<?php } else {
echo "<h1 class='cart'>Your shopping Cart is empty <br>Continue With <a href='shop.php'> Shopping </a> <br><span>Or</span><br> Continue with <a href='talk_to_astro.php'> Astrologers </a></h1><br>";
		}?>
<?php include('footer.php');?>
