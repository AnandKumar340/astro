<?php
session_start();
error_reporting(0);
include('db/conn.php');
?>
<?php include 'header.php' ?>
<?php $sql=mysqli_query($con,"select * from about_us where id=4");
                                                        while($row=mysqli_fetch_array($sql))
                                                        {
                                                            ?>
    <div class="clearfix"></div>
    <div class="innerpage-hero user-profile-banner" style="background-image : url('panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['bg_image']);?>')">
         <div class="container">
             <div class="row">
                 <div class="innerpage-hero-content">
                     <p>About</p>
 
                     <h1>GURUDEVO</h1>
                 </div>
             </div>
         </div>
     </div>
     <div class="aboutdesc">
         <div class="container">
             <div class="row">
                 <div class="col-md-12">
                     <div class="hs_about_heading_wrapper text-center">
                         <h2> <span>About</span> Us</h2>
                         <h4><span></span></h4>
                     </div>
                  
                     <p><?php echo $row['content'] ?></p>
 
                 </div>
             </div>
         </div>
     </div>
     <div class="aboutbox">
         <div class="container">
             <div class="row">
                 <div class="col-md-6">
                     <div class="text-box">
                         <div class="hs_about_heading_wrapper">
                         <h2>Know About <span> <?php echo htmlentities($row['title_first']);?></span></h2>
                         <h4><span></span></h4>
                     </div>
                      <p><?php echo $row['content_1'] ?></p>
                       </div>
                 </div>
                 <div class="col-md-6">
                     <div class="imgb-bxb">
                         <img src="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['image_1']);?>">
                     </div>
                 </div>
             </div>
         </div>
     </div>

      <div class="aboutbox guruji">
         <div class="container">
             <div class="row">
                 <div class="col-md-6">
                     <div class="imgb-bxb">
                         <img src="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['image_2']);?>">
                     </div>
                 </div>
                 <div class="col-md-6">
                     <div class="text-box">
                         <div class="hs_about_heading_wrapper">
                         <h2>Know About <span><?php echo htmlentities($row['title_second']);?></span></h2>
                         <h4><span></span></h4>
                     </div>
                      <p><?php echo $row['content_2'] ?></p>
                       </div>
                 </div>
                 
             </div>
         </div>
     </div>
                                                        <?php } ?>

                  <?php $sql=mysqli_query($con,"select * from about_why where id=1");
                         while($row=mysqli_fetch_array($sql))  { ?>
     <section class="whync four">
         <div class="container-fluide">
             <div class="row">
 
                 <div class="col-sm-6" style="background-image : url('panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['image']);?>')">
                     <div class="box pull-right">
                         <figcaption class="text-right">
                             <h4><?php echo htmlentities($row['title_1']);?></h4>
                             <p><?php echo $row['content_1'] ?></p>
                         </figcaption>
                         <figure class="icon icon1"></figure>
                     </div>
                 </div>
 
                 <div class="col-sm-6" style="background-image : url('panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['image']);?>')">
                     <div class="box pull-left">
                         <figure class="icon icon2"></figure>
                         <figcaption class="text-left">
                             <h4><?php echo htmlentities($row['title_2']);?></h4>
                             <p><?php echo $row['content_2'] ?></p>
                         </figcaption>
                     </div>
                 </div>
 
                 <div class="col-sm-6" style="background-image : url('panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['image']);?>')">
                     <div class="box pull-right">
                         <figcaption class="text-right">
                             <h4><?php echo htmlentities($row['title_3']);?></h4>
                             <p><?php echo $row['content_3'] ?></p>
                         </figcaption>
                         <figure class="icon icon3"></figure>
                     </div>
                 </div>
 
                 <div class="col-sm-6" style="background-image : url('panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['image']);?>')">
                     <div class="box pull-left">
                         <figure class="icon icon4"></figure>
                         <figcaption class="text-left">
                             <h4><?php echo htmlentities($row['title_4']);?></h4>
                             <p><?php echo $row['content_4'] ?></p>
                         </figcaption>
                     </div>
                 </div>
 
             </div>
 
             <div class="ap-add">
                 <h4 style="font-size:30px;line-height:40px"><?php echo htmlentities($row['top_title']);?></h4>
             </div>
         </div>
     </section>
                         <?php } ?>

     <!-- <section class="intro-status">
         <div class="container">
             <span>Profile</span>
             <div class="row row-centered">
                 <div class="col-xs-12 col-md-12 col-centered">
 
                     <ul>
                         <li>
                             <a href="javascript:void(0)">
 
                                 <strong>800+</strong>
                                 <p>satisfied 
                                     <br>customers</p>
                             </a>
                         </li>
                         <li>
                             <a href="javascript:void(0)">
                                 <strong>100+</strong>
                                 <p>astrologers
                                     <br>assistance</p>
                             </a>
                         </li>
                         <li>
                             <a href="javascript:void(0)">
                                 <strong>120+</strong>
                                 <p>projects
                                     <br>completed</p>
                             </a>
                         </li>
                         <li>
                             <a href="javascript:void(0)">
                                 <strong>50+</strong>
                                 <p>experienced
                                     <br>developers</p>
                             </a>
                         </li>
                     </ul>
                 </div>
             </div>
         </div>
     </section> -->
     <?php include 'experience.php' ?>
  <?php include 'footer.php' ?> 