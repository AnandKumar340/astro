<div class="hs_client_slider_main_wrapper">
   <div class="container">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
         <div class="hs_client_slider_wrapper">
            <div class="owl-carousel owl-theme">
            <?php $sql=mysqli_query($con,"select * from partners");
                                                        while($row=mysqli_fetch_array($sql))
                                                        {
                                                            ?>
                                       <div class="item">
                                          <div class="hs_client_img_wrapper">
                                          <img src="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['image']);?>" alt="Partners_Logo">
                                          </div>
                                       </div>
                                         

                                        
                                      <?php
                                          }
                                    ?>
              
             
            </div>
         </div>
      </div>
   </div>
</div>