<?php
session_start();
error_reporting(0);
include('db/conn.php');
?>
<?php include 'header.php' ?>
<div class="clearfix"></div>
<?php $sql=mysqli_query($con,"select * from contact_us");
                                                        while($row=mysqli_fetch_array($sql))
                                                        {
                                                            ?>
<div class="innerpage-hero user-profile-bann" style="background-image : url('panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['image']);?>');">
   <div class="container">
      <div class="row">
         <div class="innerpage-hero-content">
            <p><?php echo $row['title'] ?></p>
            <h1><?php echo $row['sub_title'] ?></h1>
         </div>
      </div>
   </div>
</div>
<div class="aboutdesc">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <div class="hs_about_heading_wrapper text-center">
               <h2> <span><?php echo $row['title_2'] ?></span> </h2>
               <h4><span></span></h4>
            </div>
            <p><?php echo $row['content'] ?></p>
         </div>
      </div>
   </div>
</div>
<?php } ?>

<!-- hs contact form Start -->
<!-- contcact form using php  -->
<?php
  $to = 'dev@techmarketz.in' . "\r\n";
  $subject = 'Customers Query from Gurudeve.com ';
  $name = $_POST['name'];
  $email = $_POST['email']; 
  $phone = $_POST['phone'];
  $msg = $_POST['msg'];
  $sub = $_POST['sub'];

  $message =   "Message from you website Gurudevo.com !  <br>\r\n" .
            
    
  	        "<br>Name: " . $name . "\r\n" .
            "<br>Phone: " . $phone . "\r\n" .
            "<br>E-mail: " . $email . "\r\n" .
            "<br>Subject: " . $sub . "\r\n" .
            "<br>Message: " . $msg . "\r\n" ;

  $headers = "From: " . $name . "<" . $email . "> \r\n" .
  	         "Reply-To: " . $email . "\r\n" .
             "MIME-Version: 1.0" . "\r\n" .
             "Content-type:text/html;charset=UTF-8" . "\r\n";

   mail($to, $subject, $message, $headers);
    
 ?>
 <!-- contcact form using php  -->
<div class="hs_contact_indx_form_main_wrapper">
   <div class="container">
      <div class="row">
         <form action="" method="post" id="contact-form">
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
               <div class="hs_kd_six_sec_input_wrapper">
                  <label>Name</label>
                  <input type="text" class="require" name="name" required="">
               </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
               <div class="hs_kd_six_sec_input_wrapper">
                  <label>Email</label>
                  <input type="email" class="require" name="email" data-valid="email" data-error="Email should be valid." required="">
               </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
               <div class="hs_kd_six_sec_input_wrapper">
                  <label>Phone Number</label>
                  <input type="text" class="require" name="phone" data-valid="phone" data-error="Phone Number should be valid." required="">
               </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
               <div class="hs_kd_six_sec_input_wrapper">
                  <label>Subject</label>
                  <input type="text" class="require" name="sub" data-valid="subject" data-error="subject should be valid.">
               </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <div class="hs_kd_six_sec_input_wrapper">
                  <label>Message</label>
                  <textarea rows="6" class="require" name="msg"></textarea>
               </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <div class="response"></div>
               <div class="hs_contact_indx_form_btn">
                  <ul>
                     <li>
                        <input type="hidden" name="form_type" value="contact">
                        <button type="submit" class="hs_btn_hover submitForm">Send a Message</button>
                     </li>
                  </ul>
               </div>
            </div>
         </form>
      </div>
   </div>
</div>
<!-- hs contact form End -->
<!-- hs contact us Title Start -->
<div class="hs_contact_tittle_main_wrapper">
   <div class="container">
      <div class="row">
         <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="hs_about_heading_main_wrapper">
            <?php $sql=mysqli_query($con,"select * from contact_us");
                                                        while($row=mysqli_fetch_array($sql))
                                                        {
                                                            ?>
               <div class="hs_about_heading_wrapper text-center">
                  <h2><span><?php echo $row['title_3'] ?></span></h2>
                  <h4><span></span></h4>
                  <p><?php echo $row['content_3'] ?></p>
               </div>

            </div>
         </div>
     
         <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
            <div class="hs_contact_title_box_wrapper">
               <div class="hs_service_icon_main_wrapper">
                  <div class="hs_service_icon_wrapper hs_contact_indx_icon_wrapper">
                     <i class="fa fa-phone"></i>
                     <div class="btc_step_overlay"></div>
                  </div>
               </div>
               <p><?php echo $row['phone'] ?></p>
            </div>
         </div>

         <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
            <div class="hs_contact_title_box_wrapper">
               <div class="hs_service_icon_main_wrapper">
                  <div class="hs_service_icon_wrapper hs_contact_indx_icon_wrapper">
                     <i class="fa fa-envelope"></i>
                     <div class="btc_step_overlay"></div>
                  </div>
               </div>
               <p><?php echo $row['email'] ?></p>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
            <div class="hs_contact_title_box_wrapper">
               <div class="hs_service_icon_main_wrapper">
                  <div class="hs_service_icon_wrapper hs_contact_indx_icon_wrapper">
                     <i class="fa fa-map-marker"></i>
                     <div class="btc_step_overlay"></div>
                  </div>
               </div>
               <p><?php echo $row['address'] ?></p>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- hs contact us Title End -->
<!-- hs contact map Start -->
<div class="hs_contact_map_main_wrapper">
   <div id="map"><?php echo $row['map'] ?>  </div>
</div>
<?php } ?>

<!-- hs contact map End -->

<script>
     $(document).ready(function(){
  $('#contact-form').on('submit',function(e) {  //Don't foget to change the id form
  $.ajax({
      data:$(this).serialize(),
      type:'POST',
      success:function(data){
        console.log(data);
        //Success Message == 'Title', 'Message body', Last one leave as it is
	    swal("Message sent Successfully !", "<a href='index.php' class='btn contact-btn'> OK </a>", "success");
      },
      error:function(data){
        //Error Message == 'Title', 'Message body', Last one leave as it is
	    swal("Oops...", "Something went wrong :(", "error");
      }
    });
    e.preventDefault(); //This is to Avoid Page Refresh and Fire the Event "Click"
  });
});
 </script>
<?php include 'footer.php' ?>