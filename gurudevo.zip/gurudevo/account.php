<?php include 'header.php' ?>
<?php include 'db/conn.php' ?>
<!-- hs Navigation End -->
<div class="clearfix"></div>
  <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
         <div class="modal-header">
         
         </div>
         <div class="modal-body">
            <div class="row">
               <div class="col-md-5">
                  <div class="modal-txt-left">
                     <h3>Welcome Back</h3>
                     <p>To keep connected with us Please Login with your personal info</p>
                  </div>
               </div>
               <div class="col-md-7">
                  <div class="form">
                     <div class="tab-content">

                        <div id="login">
                           <h1>Log in to Gurudevo</h1>
                           <p class="small-txt">To keep connected with us Please Login with your personal info</p>
                           <form action="login.php" method="post">
                              <div class="field-wrap">
                                 <label>
                                 Email Address<span class="req">*</span>
                                 </label>
                                 <input type="email" name="username" required autocomplete="off" >
                              </div>
                              <div class="field-wrap">
                                 <label>
                                 Password<span class="req">*</span>
                                 </label>
                                 <input type="password" name="password" required autocomplete="off" >
                              </div>
                              <p class="forgot"><a href="#">Forgot Password?</a></p>
                              <ul class="tab-group">
                                 <li><button type="submit" class="button button-block">Log In</button></li>
                                 <li class="tab"><a href="#signup" class="btn btn-transparent">Signup</a></li>
                              </ul>
                           </form>
                        </div>
                        
                       
                        <div id="signup">
                           <h1>Sign Up at Gurudevo</h1>
                           <p class="small-txt">To keep connected with us Please Sign Up with your personal info </p>
                           <form action="register.php" method="post">
                              <div class="row">
                                 <div class="col-md-12">
                                    <div class="form-group">
                                       <label>
                                       User Name<span class="req">*</span>
                                       </label>
                                       <input type="text" name="name" required autocomplete="off" >
                                    </div>
                                 </div>
                                 <div class="col-md-12">
                                    <div class="form-group">
                                       <label>
                                       Email Address<span class="req">*</span>
                                       </label>
                                       <input type="email" name="username" required autocomplete="off" >
                                    </div>
                                 </div>
                                 <div class="col-md-12">
                                    <div class="form-group">
                                       <label>
                                       Mobile Number<span class="req">*</span>
                                       </label>
                                       <input type="text" name="phone" required autocomplete="off" >
                                    </div>
                                 </div> 
                                 <div class="col-md-12">
                                    <div class="form-group">
                                       <label>
                                       Password<span class="req">*</span>
                                       </label>
                                       <input type="password" name="password" required autocomplete="off" >
                                    </div>
                                 </div>
                                 <div class="col-md-12">
                                    <div class="form-group">
                                       <label>
                                      Confirm Password<span class="req">*</span>
                                       </label>
                                       <input type="password" name="confirm_password" required autocomplete="off" >
                                    </div>
                                 </div>
                              </div>
                              <ul class="tab-group">
                              <li><input type="submit">Sign In</li>
                              </ul>
                           </form>
                        </div>
                     </div>
                     <!-- tab-content -->
                  </div>
                  <!-- /form -->
               </div>
            </div>
         </div>
      </div>
   </div>



<!--main js file start-->
<script src="js/jquery_min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/modernizr.js"></script>
<script src="js/mainhomef195.js"></script>
<script src="js/jquery.menu-aim.js"></script>
<script src="js/parallax.min.js"></script>
<script src="js/owl.carousel.js"></script>
<script src="js/jquery.shuffle.min.js"></script>
<script src="js/jquery.countTo.js"></script>
<script src="js/jquery.inview.min.js"></script>
<script src="js/jquery.magnific-popup.js"></script>
<script src="js/custom.js"></script>

</body>
</html>