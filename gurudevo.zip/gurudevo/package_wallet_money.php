<?php
session_start();
error_reporting(0);
include('db/conn.php');
?>
<?php include 'header.php' ?>
<div class="clearfix">
</div>

<div class="main-container">
   <div class="container">
      <!-- start service -->
      <div class="service">
         <h3><span>Select</span> Minutes</h3>
         <div class="row">
<!-- first Package  -->

<?php $sql=mysqli_query($con,"select * from wallet_package");
                                                while($row=mysqli_fetch_array($sql))
                                                { ?>
            <div class="col-sm-3">
               <a href="" data-toggle="modal"  id="package_1">
                  <div class="column">
                     <div class="txtb">
                     <h4><?php echo $row['time_1'] ?></h4>

                        <h3><i class="fa fa-rupee"></i> <?php echo $row['package_1'] ?></h3>
                     </div>
                  </div>
               </a>
            </div>
            <div class="demo-amount">
               <?php
               $first_number = $row['package_1'];
               $second_number = 100;
               $sum_total = $second_number * $first_number;
               print ($sum_total);
               ?>
            </div>
                  <script>
                  $order  = $client->order->create([
                  'receipt'         => 'order_rcptid_11',
                  'amount'          => '<?php print ($sum_total) ?>', // amount in the smallest currency unit
                  'currency'        => 'INR',// <a href="/docs/payment-gateway/payments/international-payments/#supported-currencies" target="_blank">See the list of supported currencies</a>.)
                  ]);
                  </script>
                  <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
                  <script>
                  var options = {
                     "key": "rzp_live_X2GeCFxdcx17sg", // Enter the Key ID generated from the Dashboard
                     "secret": "Q86RAuMPqofJ11sN8lj0u7Le",
                     "amount": "<?php print ($sum_total) ?>", // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
                     "currency": "INR",
                     "name": "Acme Corp",
                     "description": "Test Transaction",
                     "image": "http://gurudevo.in/images/logo2.png",
                     "order_id": "<?php echo $row['oid'] ?>", //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
                     "callback_url": "https://eneqd3r9zrjok.x.pipedream.net/",
                     "prefill": {
                        "name": "Gautam Ishan",
                        "email": "gautam_ishan2802@yahoo.com",
                        "contact": "9999999999"
                     },
                     "notes": {
                        "address": "Razorpay Corporate Office"
                     },
                     "theme": {
                        "color": "#F37254"
                     }
                  };
                  var rzp1 = new Razorpay(options);
                  rzp1.on('payment.failed', function (response){
                        alert(response.error.code);
                        alert(response.error.description);
                        alert(response.error.source);
                        alert(response.error.step);
                        alert(response.error.reason);
                        alert(response.error.metadata);
                  });
                  document.getElementById('package_1').onclick = function(e){
                     rzp1.open();
                     e.preventDefault();
                  }
                  </script>
<!-- /first Package  -->
<div class="col-sm-3">
               <a href="" data-toggle="modal"  id="package_2">
                  <div class="column">
                     <div class="txtb">
                     <h4><?php echo $row['time_2'] ?></h4>

                        <h3><i class="fa fa-rupee"></i> <?php echo $row['package_2'] ?></h3>
                     </div>
                  </div>
               </a>
            </div>
            <div class="demo-amount">
               <?php
               $first_number = $row['package_2'];
               $second_number = 100;
               $sum_total = $second_number * $first_number;
               print ($sum_total);
               ?>
            </div>
                  <script>
                  $order  = $client->order->create([
                  'receipt'         => 'order_rcptid_11',
                  'amount'          => '<?php print ($sum_total) ?>', // amount in the smallest currency unit
                  'currency'        => 'INR',// <a href="/docs/payment-gateway/payments/international-payments/#supported-currencies" target="_blank">See the list of supported currencies</a>.)
                  ]);
                  </script>
                  <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
                  <script>
                  var options = {
                     "key": "rzp_live_X2GeCFxdcx17sg", // Enter the Key ID generated from the Dashboard
                     "secret": "Q86RAuMPqofJ11sN8lj0u7Le",
                     "amount": "<?php print ($sum_total) ?>", // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
                     "currency": "INR",
                     "name": "Acme Corp",
                     "description": "Test Transaction",
                     "image": "http://gurudevo.in/images/logo2.png",
                     "order_id": "<?php echo $row['oid'] ?>", //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
                     "callback_url": "https://eneqd3r9zrjok.x.pipedream.net/",
                     "prefill": {
                        "name": "Gautam Ishan",
                        "email": "gautam_ishan2802@yahoo.com",
                        "contact": "9999999999"
                     },
                     "notes": {
                        "address": "Razorpay Corporate Office"
                     },
                     "theme": {
                        "color": "#F37254"
                     }
                  };
                  var rzp2 = new Razorpay(options);
                  rzp2.on('payment.failed', function (response){
                        alert(response.error.code);
                        alert(response.error.description);
                        alert(response.error.source);
                        alert(response.error.step);
                        alert(response.error.reason);
                        alert(response.error.metadata);
                  });
                  document.getElementById('package_2').onclick = function(e){
                     rzp2.open();
                     e.preventDefault();
                  }
                  </script>
<!-- /Second Package  -->
<div class="col-sm-3">
               <a href="" data-toggle="modal"  id="package_3">
                  <div class="column">
                     <div class="txtb">
                     <h4><?php echo $row['time_3'] ?></h4>

                        <h3><i class="fa fa-rupee"></i> <?php echo $row['package_3'] ?></h3>
                     </div>
                  </div>
               </a>
            </div>
            <div class="demo-amount">
               <?php
               $first_number = $row['package_3'];
               $second_number = 100;
               $sum_total = $second_number * $first_number;
               print ($sum_total);
               ?>
            </div>
                  <script>
                  $order  = $client->order->create([
                  'receipt'         => 'order_rcptid_11',
                  'amount'          => '<?php print ($sum_total) ?>', // amount in the smallest currency unit
                  'currency'        => 'INR',// <a href="/docs/payment-gateway/payments/international-payments/#supported-currencies" target="_blank">See the list of supported currencies</a>.)
                  ]);
                  </script>
                  <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
                  <script>
                  var options = {
                     "key": "rzp_live_X2GeCFxdcx17sg", // Enter the Key ID generated from the Dashboard
                     "secret": "Q86RAuMPqofJ11sN8lj0u7Le",
                     "amount": "<?php print ($sum_total) ?>", // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
                     "currency": "INR",
                     "name": "Acme Corp",
                     "description": "Test Transaction",
                     "image": "http://gurudevo.in/images/logo2.png",
                     "order_id": "<?php echo $row['oid'] ?>", //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
                     "callback_url": "https://eneqd3r9zrjok.x.pipedream.net/",
                     "prefill": {
                        "name": "Gautam Ishan",
                        "email": "gautam_ishan2802@yahoo.com",
                        "contact": "9999999999"
                     },
                     "notes": {
                        "address": "Razorpay Corporate Office"
                     },
                     "theme": {
                        "color": "#F37254"
                     }
                  };
                  var rzp3 = new Razorpay(options);
                  rzp3.on('payment.failed', function (response){
                        alert(response.error.code);
                        alert(response.error.description);
                        alert(response.error.source);
                        alert(response.error.step);
                        alert(response.error.reason);
                        alert(response.error.metadata);
                  });
                  document.getElementById('package_3').onclick = function(e){
                     rzp3.open();
                     e.preventDefault();
                  }
                  </script>
<!-- /Third Package  -->
<div class="col-sm-3">
               <a href="" data-toggle="modal"  id="package_4">
                  <div class="column">
                     <div class="txtb">
                     <h4><?php echo $row['time_4'] ?></h4>
                        <h3><i class="fa fa-rupee"></i> <?php echo $row['package_4'] ?></h3>
                     </div>
                  </div>
               </a>
            </div>
            <div class="demo-amount">
               <?php
               $first_number = $row['package_4'];
               $second_number = 100;
               $sum_total = $second_number * $first_number;
               print ($sum_total);
               ?>
            </div>
                  <script>
                  $order  = $client->order->create([
                  'receipt'         => 'order_rcptid_11',
                  'amount'          => '<?php print ($sum_total) ?>', // amount in the smallest currency unit
                  'currency'        => 'INR',// <a href="/docs/payment-gateway/payments/international-payments/#supported-currencies" target="_blank">See the list of supported currencies</a>.)
                  ]);
                  </script>
                  <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
                  <script>
                  var options = {
                     "key": "rzp_live_X2GeCFxdcx17sg", // Enter the Key ID generated from the Dashboard
                     "secret": "Q86RAuMPqofJ11sN8lj0u7Le",
                     "amount": "<?php print ($sum_total) ?>", // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
                     "currency": "INR",
                     "name": "Acme Corp",
                     "description": "Test Transaction",
                     "image": "http://gurudevo.in/images/logo2.png",
                     "order_id": "<?php echo $row['oid'] ?>", //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
                     "callback_url": "https://eneqd3r9zrjok.x.pipedream.net/",
                     "prefill": {
                        "name": "Gautam Ishan",
                        "email": "gautam_ishan2802@yahoo.com",
                        "contact": "9999999999"
                     },
                     "notes": {
                        "address": "Razorpay Corporate Office"
                     },
                     "theme": {
                        "color": "#F37254"
                     }
                  };
                  var rzp4 = new Razorpay(options);
                  rzp4.on('payment.failed', function (response){
                        alert(response.error.code);
                        alert(response.error.description);
                        alert(response.error.source);
                        alert(response.error.step);
                        alert(response.error.reason);
                        alert(response.error.metadata);
                  });
                  document.getElementById('package_4').onclick = function(e){
                     rzp4.open();
                     e.preventDefault();
                  }
                  </script>
<!-- /first Package  -->



         </div>
      </div>
      <!-- end service -->
   </div>
</div>


<!-- End Modal  -->
<?php } ?>

<?php include 'footer.php' ?>