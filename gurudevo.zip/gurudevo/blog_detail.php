<?php
session_start();
error_reporting(0);
include('db/conn.php');
?>
<?php include 'header.php' ?>
<div class="clearfix"></div>
<?php
                           
                           if (isset($_GET['id'])) {
                              $id = $_GET['id'];
                              $sql = "select * from blog where id=".$id;
                              $result = mysqli_query($conn, $sql);
                              if (mysqli_num_rows($result) > 0) {
                                 $row = mysqli_fetch_assoc($result);
                              }else {
                                 $errorMsg = 'Could not Find Any Record';
                              }
                           }
                           ?>
               <?php $sql=mysqli_query($con,"select * from blog where id='$id'");
                                                while($row=mysqli_fetch_array($sql))
                                                {
                                                    ?>

<div class="innerpage-hero user-profile-bann" style="background-image : url('panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['image']);?>');">
   <div class="container">
      <div class="row">
         <div class="innerpage-hero-content">
            <p><?php echo $row['title'] ?></p>
            <h1><?php echo $row['sub_title'] ?></h1>
            <p><?php echo $row['date_time'] ?></p>
         </div>
      </div>
   </div>
</div>

<div class="aboutdesc">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <div class="hs_about_heading_wrapper text-center">
               <h2> <span><?php echo $row['author'] ?></span> </h2>
               <h4><span></span></h4>
            </div>
            <p><?php echo $row['content'] ?></p>
         </div>
      </div>
   </div>
</div>
                                                        <?php } ?>
<?php include 'footer.php' ?>