<?php
session_start();
error_reporting(0);
include('db/conn.php');
?>
<?php include 'header.php' ?>
<div class="clearfix"></div>
    <?php $sql=mysqli_query($con,"select * from privacy_policy");
            while($row=mysqli_fetch_array($sql)) {  ?>
<div class="aboutdesc">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <div class="hs_about_heading_wrapper text-center">
               <h2> <span><?php echo $row['title'] ?></span> </h2>
               <h4><span></span></h4>

            </div>
            <p><?php echo $row['content'] ?></p>
         </div>
      </div>
   </div>
</div>
<?php } ?>


<?php include 'footer.php' ?>