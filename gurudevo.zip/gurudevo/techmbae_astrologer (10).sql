-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 05, 2020 at 12:04 PM
-- Server version: 5.6.41-84.1
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `techmbae_astrologer`
--

-- --------------------------------------------------------

--
-- Table structure for table `about_us`
--

CREATE TABLE `about_us` (
  `id` int(11) NOT NULL,
  `bg_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` varchar(10000) COLLATE utf8_unicode_ci NOT NULL,
  `title_first` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content_1` varchar(2000) COLLATE utf8_unicode_ci NOT NULL,
  `image_1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title_second` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content_2` varchar(2000) COLLATE utf8_unicode_ci NOT NULL,
  `image_2` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `about_us`
--

INSERT INTO `about_us` (`id`, `bg_image`, `content`, `title_first`, `content_1`, `image_1`, `title_second`, `content_2`, `image_2`) VALUES
(4, 'bg_how_to_work.jpg', '<p>demo&nbsp; test nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat hello Aenean world. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim <em>veniam</em><em><strong>,</strong></em> quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'this is first title ', '<p>demo&nbsp; test nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat hello Aenean world. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim <em>veniam</em><em><strong>,</strong></em> quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'about.png', 'this is second title ', '<p>&nbsp;testnibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat hello Aenean world. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'news_img1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `about_why`
--

CREATE TABLE `about_why` (
  `id` int(11) NOT NULL,
  `top_title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `title_1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content_1` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `title_2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content_2` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `title_3` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content_3` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `title_4` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content_4` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `about_why`
--

INSERT INTO `about_why` (`id`, `top_title`, `title_1`, `content_1`, `title_2`, `content_2`, `title_3`, `content_3`, `title_4`, `content_4`, `image`) VALUES
(1, 'why gurudevo', 'first title ', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim.', 'second title ', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim.', 'third title ', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim.', 'fourth title', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim.', 'about.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `creationDate`, `updationDate`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '2017-01-24 16:21:18', '03-09-2020 05:38:57 PM');

-- --------------------------------------------------------

--
-- Table structure for table `astro_service`
--

CREATE TABLE `astro_service` (
  `id` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `sub_title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `title_2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `astro_service`
--

INSERT INTO `astro_service` (`id`, `title`, `sub_title`, `content`, `title_2`, `image`) VALUES
(26, 'Kundali', 'Birth Chart', 'I am the new Sinatra, and since I made it here I can make it anywhere, yeah, they love me everywhere', 'To make your Kundali', 'kundali-icon.jpg'),
(27, 'Horoscope', 'Matching', 'A horoscope is an astrological chart or diagram representing the positions of the Sun, Moon, planets, astrological aspects.\r\n', 'To Create your Horoscope', 'horoscope.jpg'),
(28, 'Astrosage', 'Matrimony', 'A horoscope is an astrological chart or diagram representing the positions of the Sun, Moon, planets, astrological aspects', 'To Create your Astrosage', 'astrosage.jpg'),
(29, 'BRIHAT ', 'Horoscope test', '<p>A horoscope is an astrological chart or diagram representing the positions of the Sun, Moon, planets, astrological aspects</p>', 'To Create your Brihat Horoscope', 'brihat.jpg'),
(31, 'Business Related Issue', 'Horoscope', '<p>Here the expert astrologer will analyze the nature of your business and the obstacles you are facing in your business according to the current period.You can ask anything that is troubling you rela', 'To Get Your Problem Solved', 'WhatsApp Image 2020-11-04 at 19.44.26.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `sub_title` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `author` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `content` varchar(10000) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `title`, `sub_title`, `author`, `image`, `date_time`, `content`) VALUES
(15, 'Card LIsting', 'this is subtitle', 'Mr. Dayanand ', 'title_img1.jpg', '2020-10-21 12:34:01', 'This is content'),
(16, 'How to show your future ?', 'Future ', 'Mr. Anand', 'title_img2.jpg', '2020-10-21 12:35:03', 'This is content about future '),
(17, 'Palm Reading ', 'This is Palm Reading ', 'Mr. Ashutosh Bhattnagar', 'title_img3.jpg', '2020-10-21 12:45:04', 'Donec id elit non mi porta gravida at eget metus. Donec id elit non Vestibulum id ligula porta felis euism od semper. Nulla vitae elit libero Donec id elit non mi porta gravida at eget metus. Donec id elit non Vestibulum id ligula porta felis euism od semper. Nulla vitae elit libero Donec id elit non mi porta gravida at eget metus. Donec id elit non Vestibulum id ligula porta felis euism od semper. Nulla vitae elit libero Donec id elit non mi porta gravida at eget metus. Donec id elit non Vestibulum id ligula porta felis euism od semper. Nulla vitae elit libero .'),
(21, 'Astrology Zodiac', 'Aries - Mesha', 'Naman Gautam', 'thumb-aries-golden-sign-metal-background-creative-art-zodiac-signs-aries-zodiac-sign.jpg', '2020-10-30 14:16:35', '<p style=\"box-sizing: border-box; border: 0px; font-family: Roboto, sans-serif; font-size: 18px; line-height: 32.4px; margin: 0px 0px 1.1em; padding: 0px; overflow-wrap: break-word; color: #444444; background-color: #ffffff; text-align: justify;\"><em><strong>Aries </strong></em>&ndash; Mesha is the first or head sign of the zodiac. It commences at the vernal equinox and extends up to exactly 30 degrees.</p>\r\n<p style=\"box-sizing: border-box; border: 0px; font-family: Roboto, sans-serif; font-size: 18px; line-height: 32.4px; margin: 0px 0px 1.1em; padding: 0px; overflow-wrap: break-word; color: #444444; background-color: #ffffff;\">Aries is an equinoctial sign. It is fiery and hot by nature. It is termed bestial and sterile. It is a movable or a cardinal sign. It is said to be masculine or positive and is of short ascension.</p>\r\n<p style=\"box-sizing: border-box; border: 0px; font-family: Roboto, sans-serif; font-size: 18px; line-height: 32.4px; margin: 0px 0px 1.1em; padding: 0px; overflow-wrap: break-word; color: #444444; background-color: #ffffff;\">Aries is generally symbolized by a ram, being in nature rash, combative, lascivious, springy and hardy. It is called an oriental sign denoting the beginning of right ascension. Aries represents head and face in human body. It is ruled by mars. Sun is exalted in this sign. Saturn is debilitated, whereas Venus is said to be in its fall in this sign.</p>\r\n<p style=\"box-sizing: border-box; border: 0px; font-family: Roboto, sans-serif; font-size: 18px; line-height: 32.4px; margin: 0px 0px 1.1em; padding: 0px; overflow-wrap: break-word; color: #444444; background-color: #ffffff;\"><strong style=\"box-sizing: border-box; margin-bottom: 0px;\">&nbsp;</strong>People born under this sign are of middle stature. They posses a lean and muscular body. They are neither stout nor thick. Their complexion will be ruddy and they have fairly long neck and face. Their head will be broad at the temples and narrow at the chin. They have bushy eyebrows, eyes grey to grayish brown with sharp sight. Their hair will wiry, color varying from dark to sandy.</p>\r\n<p style=\"box-sizing: border-box; border: 0px; font-family: Roboto, sans-serif; font-size: 18px; line-height: 32.4px; margin: 0px 0px 1.1em; padding: 0px; overflow-wrap: break-word; color: #444444; background-color: #ffffff;\"><strong style=\"box-sizing: border-box; margin-bottom: 0px;\">&nbsp;</strong>As mars rules this sign, the people born in Aries will be ever active and ambitious. They are bold and impulsive, sometimes rash and aggressive also. Beneficial aspects give them confidence and courage. They always aim high and ever enterprising. Being a positive sign, it gives determination and force of character. Arians act quickly with unbounded self-confidence. They will not hesitate to change whatever they dislike and whenever they want. Persons born under this sign will desire to be the head of all affairs. They do not relish suggestions from other but act according to their own judgement. They dislike to be subordination but wish to be the leaders in thought and action. They have much of executive ability and uncompromising spirit. Most of the time they will not sacrifice their personal desires for others and if they do then the reason would inexpiable for them. They will try to stick on their own views. sometimes they underestimate others and are over-optimistic. Consistency is not their virtue. Evil planets in the ascendant make them aggressive, proud, arrogant, headstrong, hasty and quarrelsome.</p>\r\n<p style=\"box-sizing: border-box; border: 0px; font-family: Roboto, sans-serif; font-size: 18px; line-height: 32.4px; margin: 0px 0px 1.1em; padding: 0px; overflow-wrap: break-word; color: #444444; background-color: #ffffff;\">Arians require plenty of rest and sleep and also good food and plenty of vegetables. They have to relax and control their feelings. They should avoid worry, excitement and anger. As a patient, the native becomes impatient of sickness and tries to have a quick recovery. They have to avoid stimulants and take less of meant.</p>\r\n<p style=\"box-sizing: border-box; border: 0px; font-family: Roboto, sans-serif; font-size: 18px; line-height: 32.4px; margin: 0px 0px 1.1em; padding: 0px; overflow-wrap: break-word; color: #444444; background-color: #ffffff;\">I will be writing about each sign every week so stay tuned !!</p>'),
(24, 'Astrology Zodiac', 'Gemini - Mithunam', 'Naman Gautam', 'coloring-pages-gemini-zodiac-sign-artwork-adult-book-page-beautiful-symbol-vector-id1156022344-fabulous.jpg', '2020-11-04 14:17:47', '<p style=\"box-sizing: border-box; border: 0px; font-family: Roboto, sans-serif; font-size: 18px; line-height: 32.4px; margin: 0px 0px 1.1em; padding: 0px; overflow-wrap: break-word; color: #444444; background-color: #ffffff;\">Gemini is the third sign of the zodiac. It is the first of the airy signs. Gemini is masculine and positive. In astrology it is classified as barren sign. It is rules by planet Mercury, son of sun and moon. No planet gets either exaltation or debilitation in this sign, but Jupiter is said to be in its detriment in this sign as it is the house that opposes Sagittarius owned by Jupiter, so Sagittarians are not very friendly with geminians. Mercury is effeminate, but an intellectual planet. To Saturn and Venus this sign is said to be friendly so Aquarians, Capricorns, Taurians and Librans are quiet friendly with them.</p>\r\n<p style=\"box-sizing: border-box; border: 0px; font-family: Roboto, sans-serif; font-size: 18px; line-height: 32.4px; margin: 0px 0px 1.1em; padding: 0px; overflow-wrap: break-word; color: #444444; background-color: #ffffff;\">Gemini gives a tall, upright and straight body. Normally the hands are long. The legs will be thin and veins will be easily visible. Complexion will be moderate. depends on the planet uprising at the time of birth. The eyes will be hazel and look quick, sharp and active. Nose will be long.</p>\r\n<p style=\"box-sizing: border-box; border: 0px; font-family: Roboto, sans-serif; font-size: 18px; line-height: 32.4px; margin: 0px 0px 1.1em; padding: 0px; overflow-wrap: break-word; color: #444444; background-color: #ffffff;\">Being an airy sign, people born in this sign live mostly in the mind. They will be carefree and joyous and somewhat reluctant. Their intellectual will be high and mind will be positive and strong. they are versatile and restless. People born under this sign inclined to have changes often.</p>\r\n<p style=\"box-sizing: border-box; border: 0px; font-family: Roboto, sans-serif; font-size: 18px; line-height: 32.4px; margin: 0px 0px 1.1em; padding: 0px; overflow-wrap: break-word; color: #444444; background-color: #ffffff;\">As mercury is the lord of the sign, one will be inclined towards reading, writing and corresponding often. They are more social and keen to learn about various things. They can understand people and adopt themselves readily to circumstances. They have a good command over language, good convincing power can successfully explain merits and demerits of a case but they lack in leadership qualities such as commanding.&nbsp;<em style=\"box-sizing: border-box; border: 0px; font-family: inherit; line-height: 1; margin: 0px; padding: 0px;\">They can be very good right hand of the king.</em></p>\r\n<p style=\"box-sizing: border-box; border: 0px; font-family: Roboto, sans-serif; font-size: 18px; line-height: 32.4px; margin: 0px 0px 1.1em; padding: 0px; overflow-wrap: break-word; color: #444444; background-color: #ffffff;\">Gemini is termed as&nbsp;<em style=\"box-sizing: border-box; border: 0px; font-family: inherit; line-height: 1; margin: 0px; padding: 0px;\">Twins</em>. Mercury the lord of the sign is depicted as a boy, among all gods, not fully grown still in his teens. In the ancient symbolic pictures, The twins were brothers and sisters. Mercury is also said to be the&nbsp;<strong style=\"box-sizing: border-box;\">&rdquo; winged messenger of the god</strong>&nbsp;<strong style=\"box-sizing: border-box; margin-bottom: 0px;\">&ldquo;.&nbsp;</strong>Mercury has both wings on its helmet and also sandals. That is why Geminians are very quick It is said that people with some important and big things to express, generally elect the time of Gemini as they have faith that this sign will give sharp intelligence, adaptability and ultimately grand success.</p>\r\n<p style=\"box-sizing: border-box; border: 0px; font-family: Roboto, sans-serif; font-size: 18px; line-height: 32.4px; margin: 0px 0px 1.1em; padding: 0px; overflow-wrap: break-word; color: #444444; background-color: #ffffff;\"><img class=\"alignnone size-full wp-image-423\" style=\"box-sizing: border-box; border: 0px; font-family: inherit; line-height: 1; margin: 0px; padding: 0px; height: auto; max-width: 100%;\" src=\"https://gautamnaman.files.wordpress.com/2017/10/1d90af01d02ff2a0b58dd4aee6d7cb43.jpg?w=736\" sizes=\"(max-width: 736px) 100vw, 736px\" srcset=\"https://gautamnaman.files.wordpress.com/2017/10/1d90af01d02ff2a0b58dd4aee6d7cb43.jpg?w=736 736w, https://gautamnaman.files.wordpress.com/2017/10/1d90af01d02ff2a0b58dd4aee6d7cb43.jpg?w=150 150w, https://gautamnaman.files.wordpress.com/2017/10/1d90af01d02ff2a0b58dd4aee6d7cb43.jpg?w=300 300w, https://gautamnaman.files.wordpress.com/2017/10/1d90af01d02ff2a0b58dd4aee6d7cb43.jpg?w=768 768w, https://gautamnaman.files.wordpress.com/2017/10/1d90af01d02ff2a0b58dd4aee6d7cb43.jpg?w=1024 1024w, https://gautamnaman.files.wordpress.com/2017/10/1d90af01d02ff2a0b58dd4aee6d7cb43.jpg 1402w\" alt=\"1d90af01d02ff2a0b58dd4aee6d7cb43\" data-attachment-id=\"423\" data-permalink=\"https://gautamnaman.wordpress.com/2017/10/23/gemini-mitunam/1d90af01d02ff2a0b58dd4aee6d7cb43/\" data-orig-file=\"https://gautamnaman.files.wordpress.com/2017/10/1d90af01d02ff2a0b58dd4aee6d7cb43.jpg\" data-orig-size=\"1402,1068\" data-comments-opened=\"1\" data-image-meta=\"{&quot;aperture&quot;:&quot;0&quot;,&quot;credit&quot;:&quot;&quot;,&quot;camera&quot;:&quot;&quot;,&quot;caption&quot;:&quot;&quot;,&quot;created_timestamp&quot;:&quot;0&quot;,&quot;copyright&quot;:&quot;&quot;,&quot;focal_length&quot;:&quot;0&quot;,&quot;iso&quot;:&quot;0&quot;,&quot;shutter_speed&quot;:&quot;0&quot;,&quot;title&quot;:&quot;&quot;,&quot;orientation&quot;:&quot;0&quot;}\" data-image-title=\"1d90af01d02ff2a0b58dd4aee6d7cb43\" data-image-description=\"\" data-medium-file=\"https://gautamnaman.files.wordpress.com/2017/10/1d90af01d02ff2a0b58dd4aee6d7cb43.jpg?w=300\" data-large-file=\"https://gautamnaman.files.wordpress.com/2017/10/1d90af01d02ff2a0b58dd4aee6d7cb43.jpg?w=736\" /></p>\r\n<p style=\"box-sizing: border-box; border: 0px; font-family: Roboto, sans-serif; font-size: 18px; line-height: 32.4px; margin: 0px 0px 1.1em; padding: 0px; overflow-wrap: break-word; color: #444444; background-color: #ffffff;\">Being a common sign and the third sign of the zodiac, these people will have a liking towards travel frequently. These may be mainly short journeys by land. They are always active with facile mind. One of the basic characteristic of Geminians is that before taking the decision the tend to consider the advantages and disadvantages of the case then only proceed further, they never haste in decision making.</p>\r\n<p style=\"box-sizing: border-box; border: 0px; font-family: Roboto, sans-serif; font-size: 18px; line-height: 32.4px; margin: 0px 0px 1.1em; padding: 0px; overflow-wrap: break-word; color: #444444; background-color: #ffffff;\"><strong style=\"box-sizing: border-box; margin-bottom: 0px;\"><em style=\"box-sizing: border-box; border: 0px; font-family: inherit; line-height: 1; margin: 0px; padding: 0px;\">Gemini is called the house of oscillation and vacillation, these people are changeable; they are apt to diffuse their energies and spread their actions on diverse objects.</em></strong></p>\r\n<p style=\"box-sizing: border-box; border: 0px; font-family: Roboto, sans-serif; font-size: 18px; line-height: 32.4px; margin: 0px 0px 1.1em; padding: 0px; overflow-wrap: break-word; color: #444444; background-color: #ffffff;\">Being a dual sign, it gives the native the ability to follow more than one occupation at a time and also to adopt oneself to new surroundings. A little suggestion&nbsp;<em style=\"box-sizing: border-box; border: 0px; font-family: inherit; line-height: 1; margin: 0px; padding: 0px;\">a Gemini must always know their limits never go to extremes this will eventually harm them in the end.</em>&nbsp; They have few a few faults as fickleness and leaving the work unfinished. They will take up some work and while doing it, they will go on to another which also they are apt to leave unfinished. Therefore, they can be at their best when they co-operate with others and undertake to do any job. The dual sign makes them both generous and niggardly. Geminians never let emotions do any harm in their work, even if they are highly timid and nervous they will gather courage and present a courageous front and assertive attitude. They love diversity ; like the air to which they belong ; they have to be moving from place to place or from one thought to the other. They are free birds and refused to be bound by rules and habits.</p>\r\n<p style=\"box-sizing: border-box; border: 0px; font-family: Roboto, sans-serif; font-size: 18px; line-height: 32.4px; margin: 0px 0px 1.1em; padding: 0px; overflow-wrap: break-word; color: #444444; background-color: #ffffff;\">Being ruled by the Mercury, the native will have much of the curiosity and will seek after facts. He will go deep into matters as though he is doing research. He will prove to be a good detective, a brilliant journalist, and an excellent schemer. He is apt for the Human resource management. They have the talent for languages and Gemini being an intellectual sign, they doesn&rsquo;t face much of the difficulty in remembering things. It is said&nbsp;<em style=\"box-sizing: border-box; border: 0px; font-family: inherit; line-height: 1; margin: 0px; padding: 0px;\">Geminians have too many irons in the fire.</em>&nbsp;Their range of thought is very wide. Their viewpoint is always reasonable. They are practical in life and ask many questions.</p>');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `categoryName` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `categoryDescription` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `creationDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `categoryName`, `categoryDescription`, `image`, `creationDate`, `updationDate`) VALUES
(54, 'Rudraksh ', 'Rudraksha is a seed which is produced by several species of large, evergreen, broad-leaved tree in the Genus Elaeocarpus, the principle of which is Elaeocarpus Ganitrus. Rudraksha seeds are covered with a blue outer husk when fully ripe and are also known as blueberry beads. The blue color is not derived from pigment but is structural. These fruits are also known as Amritphala (Fruits of Nectar). There are many kind of Rudraksha on the basis of lines (Mukh) on it and its formation. Each kind of Rudraksha has different purpose and give different kind of benefits to wearer. <br>\r\nSpiritual Reason To Wear Rudraksha: \r\nThe word rudraksha is derived from two words – Rudra (रुद्र) and Aksha (अक्ष). The combination of these two words makes the word “Rudraksha” and it has two meanings. \r\n\r\n“Aksha means eye. Rudra and aksha means the one who is capable of looking at and doing everything (for example, the third eye). It has the capability to become the third eye of a human which gives more posit', '7.jpeg', '2020-10-16 11:15:46', '30-10-2020 05:04:37 PM'),
(57, 'Gemstone', 'This is Gemstone', '12.jpg', '2020-10-16 12:47:01', ''),
(58, 'Rosaries & Others', '<p>This is Shriyantram</p>', '16.jpg', '2020-10-16 12:47:38', '02-11-2020 03:53:41 PM');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(11) NOT NULL,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `sub_title` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `title_2` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `content` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title_3` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content_3` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `map` varchar(2000) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `title`, `sub_title`, `title_2`, `content`, `image`, `title_3`, `content_3`, `phone`, `email`, `address`, `map`) VALUES
(1, 'Contact Us', 'Get In Touch At Gurudevo', 'Contact Us', 'Leave a message for any Query and feedback.', 'bg_how_to_work.jpg', 'Get In Touch', 'You can easily connect us.', '1234567890 <br>\r\n9876543210 <br>', 'info@gurudevo.com <br>\r\nservice@gurudevo.com', 'Rani Bagh, Pitampura New Delhi. <br>110011\r\n', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3500.092315773808!2d77.\r\n      13285491508385!3d28.686884982396336!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d038e0415bae9%3A0x45c46efd868109fd!2sTechmarketz%20Delhi%20-\r\n      %20Digital%20Marketing%20Services%20%7C%20Web%20Designing%20%7C%20SEO%20%26%20Paid%20Services!5e0!3m2!1sen!2sin!4v1598880498915!5m2!1sen!2sin\"\r\n      width=\"100%\" height=\"450\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\" aria-hidden=\"false\" tabindex=\"0\"></iframe>');

-- --------------------------------------------------------

--
-- Table structure for table `experience`
--

CREATE TABLE `experience` (
  `id` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `number` int(10) NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `experience`
--

INSERT INTO `experience` (`id`, `title`, `number`, `image`) VALUES
(3, 'Kundali Meetup ', 25, 'title_img1.jpg'),
(6, 'Card Matching', 20, 'title_img2.jpg'),
(10, 'Palm Reading', 20, 'title_img3.jpg'),
(11, 'Satisfied Customers', 356, 'man-wearing-blue-button-up-top-pointing-png-clip-art.jpg'),
(12, 'Visitors / Month', 200, 'testi_client_img2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `experts`
--

CREATE TABLE `experts` (
  `id` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(250) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `experts`
--

INSERT INTO `experts` (`id`, `title`, `image`) VALUES
(4, 'Mr. Dayanand Shastri', 'online3.jpg'),
(5, 'Suruchi Jain', 'online2 (1).jpg'),
(6, 'Deepak Bhaskar', 'online1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `id` int(11) NOT NULL,
  `title_1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content_1` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `title_2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content_2` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `title_3` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content_3` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `title_4` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content_4` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `title_5` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content_5` varchar(500) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`id`, `title_1`, `content_1`, `title_2`, `content_2`, `title_3`, `content_3`, `title_4`, `content_4`, `title_5`, `content_5`) VALUES
(1, '1 This is first question ?', '<p>This is first <em><strong>answer </strong></em>for first question.</p>', '2 test', '<p>test</p>', '3 test', '<p>test</p>', '4 test', '<p>test</p>', '5 test', '<p>test</p>');

-- --------------------------------------------------------

--
-- Table structure for table `footer`
--

CREATE TABLE `footer` (
  `id` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `footer`
--

INSERT INTO `footer` (`id`, `title`, `content`, `image`) VALUES
(1, 'Gurudevo.com', 'Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum\r\nauctor, nisi elit consequat hello Aenean world.', 'footer_logo.png'),
(2, 'Talk to Our Experts', 'Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum\r\nauctor, nisi elit consequat hello Aenean world.', 'logo.png');

-- --------------------------------------------------------

--
-- Table structure for table `home_banner`
--

CREATE TABLE `home_banner` (
  `id` int(11) NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `point_1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `icon_1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `point_2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `icon_2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `point_3` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `icon_3` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `point_4` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `icon_4` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `point_5` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `icon_5` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `home_banner`
--

INSERT INTO `home_banner` (`id`, `image`, `image2`, `title`, `content`, `point_1`, `icon_1`, `point_2`, `icon_2`, `point_3`, `icon_3`, `point_4`, `icon_4`, `point_5`, `icon_5`) VALUES
(2, 'slide.jpg', 'logo--.png', 'Astrology', 'Astrology is a pseudoscience that claims to divine information about human affairs and terrestrial events \r\nby studying the movements and relative positions of celestial objects', 'Love Tarot', 'heart', 'Vasthusastra', 'home', 'Carrer Tarot', 'user', 'Chinese Astrology', 'star', 'Numerology', 'desktop'),
(3, 'bg_how_to_work.jpg', 'logo.png', 'horoscope', 'Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio.', 'Love Tarot', 'heart', 'Vasthusastra', 'home', 'Carrer Tarot', 'user', 'Chinese Astrology', 'star', 'Numerology', 'desktop');

-- --------------------------------------------------------

--
-- Table structure for table `home_card`
--

CREATE TABLE `home_card` (
  `id` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `sub_title` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `content` varchar(2000) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `home_card`
--

INSERT INTO `home_card` (`id`, `title`, `sub_title`, `content`, `image`) VALUES
(1, 'Palm Reading', ' Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin lorem quis. ', '<p>Proin gravida nibh vel velit auctor aliquet.</p>\r\n<p>Aenean sollicitudin lorem quis. Proin gravida nibh vel velit auctor aliquet.</p>\r\n<p>Aenean sollicitudin lorem quis. Proin gravida nibh vel velit auctor aliquet.</p>\r\n<p>Aenean sollicitudin lorem quis. Proin gravida nibh vel velit auctor aliquet.</p>\r\n<p>Aenean sollicitudin lorem quis. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin lorem quis.</p>', 'title_img3.jpg'),
(2, 'Luck Meter', 'This is Luck Meter for your and your relators. ', 'This is Luck Meter for your and your relators. This is Luck Meter for your and your relators. This is Luck Meter for your and your relators. This is Luck Meter for your and your relators. This is Luck Meter for your and your relators. This is Luck Meter for your and your relators. ', 'title_img2.jpg'),
(3, 'Future Luck card', 'This is future luck card for you and your relators. ', 'This is future luck card for you and your relators. This is future luck card for you and your relators. This is future luck card for you and your relators. This is future luck card for you and your relators. This is future luck card for you and your relators. This is future luck card for you and your relators. This is future luck card for you and your relators. This is future luck card for you and your relators. This is future luck card for you and your relators. This is future luck card for you and your relators. This is future luck card for you and your relators. This is future luck card for you and your relators. This is future luck card for you and your relators. This is future luck card for you and your relators. This is future luck card for you and your relators. This is future luck card for you and your relators. This is future luck card for you and your relators. This is future luck card for you and your relators. This is future luck card for you and your relators. This is future luck card for you and your relators. This is future luck card for you and your relators. This is future luck card for you and your relators. ', 'title_img1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `horoscope`
--

CREATE TABLE `horoscope` (
  `id` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `profession` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `luck` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `emotion` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `health` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `love` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `travel` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `dt` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `icon` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `horoscope`
--

INSERT INTO `horoscope` (`id`, `title`, `profession`, `luck`, `emotion`, `health`, `love`, `travel`, `dt`, `icon`) VALUES
(1, 'Aries ', '<p>This is profession description for testing.&nbsp;</p>', '', '', '', '', '', '21 October 2020', 'aries '),
(2, 'Taurus ', '', '', '', '', '', '', '14/10/2020', 'taurus'),
(3, 'Gemini', '', '', '', '', '', '\r\n', '14/10/2020', 'gemini-zodiac-sign-symbol'),
(4, 'Cancer', '\r\n', '', '', '', '', '', '16/10/2020', 'cancer'),
(5, 'Leo', '', '', '', '', '', '', '', 'leo'),
(6, 'Virgo', '', '', '', '', '', '', '', 'virgo'),
(7, 'Liba', '', '', '', '', '', '', '', 'libra'),
(8, 'Scorpio', '', '', '', '', '', '', '', 'scorpio'),
(9, 'Sagittairus', '', '', '', '', '', '', '', 'leo'),
(10, 'Capricorn', '', '', '', '', '', '', '', 'capricorn'),
(11, 'Aquarius', '', '', '', '', '', '', '', 'aquarius'),
(12, 'Pisces ', '', '', '', '', '', '', '12/10/2020', 'pisces');

-- --------------------------------------------------------

--
-- Table structure for table `how_work`
--

CREATE TABLE `how_work` (
  `id` int(11) NOT NULL,
  `title` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `sub_title` varchar(400) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `how_work`
--

INSERT INTO `how_work` (`id`, `title`, `sub_title`, `image`) VALUES
(3, 'Choose from Available Astrology Services', 'You may ask a query, get a report, speak to astrologer on call or chat live and get answers immediately.', 'home1.png'),
(4, 'Recharge your astrology wallet', 'Choose any denomination and recharge your wallet.', 'moneywallet.png'),
(5, 'Select any qualified Astrologer', 'View skills, experience, reviews complete profile of Astrologer before placing an order.', 'chathome.png'),
(6, 'Private and Confidential', 'Connect with Astrologer get complete Astrology predictions. Your data is secure confidential.', 'homenw.png');

-- --------------------------------------------------------

--
-- Table structure for table `know_about_2`
--

CREATE TABLE `know_about_2` (
  `id` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content` varchar(10000) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `productId` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `orderDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `paymentMethod` varchar(50) DEFAULT NULL,
  `orderStatus` varchar(55) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `userId`, `productId`, `quantity`, `orderDate`, `paymentMethod`, `orderStatus`) VALUES
(1, 1, '3', 1, '2017-03-07 19:32:57', 'COD', NULL),
(3, 1, '4', 1, '2017-03-10 19:43:04', 'Debit / Credit card', 'Delivered'),
(4, 1, '17', 1, '2017-03-08 16:14:17', 'COD', 'in Process'),
(5, 1, '3', 1, '2017-03-08 19:21:38', 'COD', NULL),
(6, 1, '4', 1, '2017-03-08 19:21:38', 'COD', NULL),
(7, 1, '23', 1, '2020-08-31 10:31:18', 'Internet Banking', NULL),
(8, 1, '24', 1, '2020-08-31 10:31:18', 'Internet Banking', NULL),
(9, 5, '26', 1, '2020-09-04 03:10:48', 'COD', NULL),
(10, 5, '37', 1, '2020-09-04 12:22:56', 'Internet Banking', NULL),
(11, 5, '91', 1, '2020-09-04 12:22:56', 'Internet Banking', NULL),
(12, 5, '113', 1, '2020-09-05 08:19:37', 'Debit / Credit card', NULL),
(13, 5, '33', 1, '2020-09-05 11:50:15', 'Debit / Credit card', NULL),
(14, 5, '37', 1, '2020-09-05 11:50:15', 'Debit / Credit card', NULL),
(15, 5, '33', 1, '2020-09-05 12:05:36', 'Debit / Credit card', NULL),
(16, 5, '40', 1, '2020-09-05 12:05:36', 'Debit / Credit card', NULL),
(17, 5, '37', 1, '2020-09-05 12:09:29', 'Internet Banking', NULL),
(18, 1, '30', 1, '2020-09-05 12:13:35', 'Debit / Credit card', NULL),
(19, 1, '36', 1, '2020-09-05 12:21:55', 'COD', NULL),
(20, 5, '113', 1, '2020-09-07 06:17:48', 'Internet Banking', NULL),
(21, 5, '33', 1, '2020-09-07 06:31:46', 'Internet Banking', NULL),
(22, 7, '155', 1, '2020-10-12 10:06:33', NULL, NULL),
(23, 7, '154', 1, '2020-10-12 10:12:59', NULL, NULL),
(24, 7, '154', 1, '2020-10-12 15:35:34', NULL, NULL),
(25, 7, '155', 5, '2020-10-12 15:35:34', NULL, NULL),
(26, 7, '155', 1, '2020-10-13 05:15:49', NULL, NULL),
(27, 7, '155', 1, '2020-10-13 09:21:20', NULL, NULL),
(28, 7, '156', 1, '2020-10-13 11:04:43', NULL, NULL),
(29, 7, '154', 1, '2020-10-13 12:45:01', NULL, NULL),
(30, 8, '154', 1, '2020-10-14 07:29:59', NULL, NULL),
(31, 9, '155', 6, '2020-10-14 07:34:44', NULL, NULL),
(32, 1, '155', 6, '2020-10-14 07:51:13', NULL, NULL),
(33, 1, '155', 6, '2020-10-14 07:52:12', NULL, NULL),
(34, 7, '154', 1, '2020-10-15 11:21:31', NULL, NULL),
(35, 7, '155', 1, '2020-10-15 12:35:29', NULL, NULL),
(36, 7, '155', 6, '2020-10-15 12:35:57', NULL, NULL),
(37, 7, '154', 4, '2020-10-16 05:19:39', NULL, NULL),
(38, 7, '159', 1, '2020-10-19 11:39:43', NULL, NULL),
(39, 7, '161', 1, '2020-10-19 11:55:01', NULL, NULL),
(40, 7, '161', 5, '2020-10-19 12:02:25', NULL, NULL),
(41, 7, '162', 7, '2020-10-19 12:02:25', NULL, NULL),
(42, 7, '160', 3, '2020-10-19 12:03:57', NULL, NULL),
(43, 7, '161', 5, '2020-10-19 12:03:57', NULL, NULL),
(44, 7, '162', 1, '2020-10-19 12:03:57', NULL, 'Delivered'),
(45, 7, '160', 1, '2020-10-19 12:12:14', NULL, 'Delivered'),
(46, 7, '161', 5, '2020-10-19 12:12:14', NULL, NULL),
(47, 7, '162', 1, '2020-10-19 12:12:14', NULL, NULL),
(48, 7, '163', 4, '2020-10-19 12:12:14', NULL, NULL),
(49, 10, '163', 1, '2020-10-19 12:15:26', NULL, NULL),
(50, 7, '161', 5, '2020-10-19 12:53:11', NULL, NULL),
(51, 7, '162', 1, '2020-10-19 12:53:11', NULL, NULL),
(52, 7, '163', 1, '2020-10-19 12:53:11', NULL, NULL),
(53, 7, '167', 4, '2020-10-19 12:53:11', NULL, NULL),
(54, 7, '161', 5, '2020-10-19 13:07:05', NULL, NULL),
(55, 7, '162', 1, '2020-10-19 13:07:05', NULL, NULL),
(56, 7, '163', 1, '2020-10-19 13:07:05', NULL, NULL),
(57, 7, '167', 1, '2020-10-19 13:07:05', NULL, NULL),
(58, 7, '173', 1, '2020-10-19 13:07:05', NULL, NULL),
(59, 7, '164', 1, '2020-10-20 05:40:47', NULL, 'Delivered'),
(60, 1, '164', 1, '2020-10-20 07:19:07', NULL, NULL),
(61, 1, '176', 1, '2020-10-20 07:19:07', NULL, NULL),
(62, 1, '164', 1, '2020-10-20 11:45:08', NULL, NULL),
(63, 1, '173', 1, '2020-10-20 11:45:08', NULL, NULL),
(64, 1, '176', 4, '2020-10-20 11:45:08', NULL, NULL),
(65, 1, '164', 1, '2020-10-20 11:45:31', NULL, NULL),
(66, 1, '173', 1, '2020-10-20 11:45:31', NULL, NULL),
(67, 1, '176', 4, '2020-10-20 11:45:31', NULL, NULL),
(68, 7, '173', 4, '2020-10-21 06:25:34', NULL, NULL),
(69, 11, '167', 3, '2020-10-22 06:31:24', NULL, NULL),
(70, 1, '167', 8, '2020-10-22 07:11:39', NULL, NULL),
(71, 1, '176', 2, '2020-10-22 07:11:39', NULL, NULL),
(72, 7, '173', 1, '2020-10-24 08:35:50', NULL, NULL),
(73, 1, '173', 1, '2020-10-24 10:16:24', NULL, NULL),
(74, 7, '186', 1, '2020-10-27 10:10:46', NULL, 'Delivered'),
(75, 7, '186', 1, '2020-10-27 10:30:01', NULL, NULL),
(76, 7, '186', 1, '2020-10-27 10:38:58', NULL, NULL),
(77, 7, '186', 1, '2020-10-27 10:42:13', NULL, NULL),
(78, 7, '186', 1, '2020-10-27 10:44:12', NULL, NULL),
(79, 7, '186', 1, '2020-10-27 10:45:09', NULL, NULL),
(80, 7, '186', 1, '2020-10-27 10:46:58', NULL, NULL),
(81, 7, '167', 1, '2020-10-27 11:35:46', NULL, NULL),
(82, 7, '167', 1, '2020-10-27 11:47:19', NULL, NULL),
(83, 7, '175', 1, '2020-10-27 11:58:34', NULL, NULL),
(84, 7, '175', 2, '2020-10-27 12:09:51', NULL, NULL),
(85, 7, '175', 2, '2020-10-27 12:10:03', NULL, NULL),
(86, 7, '175', 3, '2020-10-27 12:10:38', NULL, NULL),
(87, 7, '175', 3, '2020-10-27 12:11:13', NULL, NULL),
(88, 7, '175', 6, '2020-10-27 12:22:54', NULL, NULL),
(89, 7, '186', 1, '2020-10-27 12:22:54', NULL, NULL),
(90, 7, '175', 6, '2020-10-27 12:29:52', NULL, NULL),
(91, 7, '186', 1, '2020-10-27 12:29:52', NULL, NULL),
(92, 7, '186', 1, '2020-10-28 06:42:43', NULL, NULL),
(93, 7, '186', 1, '2020-10-28 06:50:43', NULL, NULL),
(94, 7, '186', 1, '2020-10-28 06:50:56', NULL, NULL),
(95, 7, '186', 1, '2020-10-28 06:53:03', NULL, NULL),
(96, 7, '175', 1, '2020-10-28 07:09:45', NULL, NULL),
(97, 7, '186', 1, '2020-10-28 07:09:45', NULL, NULL),
(98, 7, '175', 1, '2020-10-28 07:24:53', NULL, NULL),
(99, 7, '186', 1, '2020-10-28 07:24:53', NULL, NULL),
(100, 7, '187', 1, '2020-10-28 07:24:53', NULL, 'Delivered'),
(101, 7, '187', 1, '2020-10-28 07:27:26', NULL, NULL),
(102, 7, '187', 1, '2020-10-28 07:29:35', NULL, NULL),
(103, 7, '187', 5, '2020-10-28 07:35:45', NULL, 'Delivered'),
(104, 7, '187', 1, '2020-10-28 07:44:55', NULL, NULL),
(105, 7, '188', 1, '2020-10-28 07:44:55', NULL, NULL),
(106, 7, '189', 1, '2020-10-28 07:44:55', NULL, NULL),
(107, 7, '187', 1, '2020-10-28 07:59:48', NULL, NULL),
(108, 7, '187', 1, '2020-10-28 08:04:19', NULL, NULL),
(109, 7, '187', 1, '2020-10-28 08:41:45', NULL, NULL),
(110, 13, '187', 1, '2020-10-28 08:54:10', NULL, NULL),
(111, 13, '188', 1, '2020-10-28 08:54:10', NULL, NULL),
(112, 7, '191', 1, '2020-10-28 10:57:26', NULL, NULL),
(113, 7, '187', 1, '2020-10-28 11:39:27', NULL, NULL),
(114, 7, '188', 1, '2020-10-28 11:39:27', NULL, NULL),
(115, 7, '190', 2, '2020-10-30 08:22:47', NULL, 'Delivered'),
(116, 7, '190', 2, '2020-10-30 08:26:06', NULL, NULL),
(117, 7, '190', 4, '2020-10-30 08:27:23', NULL, NULL),
(118, 7, '187', 1, '2020-10-30 11:14:18', NULL, NULL),
(119, 7, '187', 2, '2020-10-30 12:46:44', NULL, NULL),
(120, 7, '187', 2, '2020-10-30 12:49:01', NULL, NULL),
(121, 7, '187', 2, '2020-10-30 12:49:42', NULL, NULL),
(122, 7, '187', 2, '2020-10-30 12:52:31', NULL, NULL),
(123, 7, '195', 1, '2020-10-30 12:52:31', NULL, NULL),
(124, 7, '187', 2, '2020-10-30 12:54:36', NULL, NULL),
(125, 7, '195', 1, '2020-10-30 12:54:36', NULL, NULL),
(126, 7, '195', 1, '2020-10-30 15:28:06', NULL, NULL),
(127, 7, '192', 3, '2020-11-04 05:31:52', NULL, NULL),
(128, 14, '191', 1, '2020-11-04 05:39:43', NULL, 'in Process'),
(129, 7, '187', 1, '2020-11-05 05:26:13', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ordertrackhistory`
--

CREATE TABLE `ordertrackhistory` (
  `id` int(11) NOT NULL,
  `orderId` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `remark` mediumtext,
  `postingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ordertrackhistory`
--

INSERT INTO `ordertrackhistory` (`id`, `orderId`, `status`, `remark`, `postingDate`) VALUES
(1, 3, 'in Process', 'Order has been Shipped.', '2017-03-10 19:36:45'),
(2, 1, 'Delivered', 'Order Has been delivered', '2017-03-10 19:37:31'),
(3, 3, 'Delivered', 'Product delivered successfully', '2017-03-10 19:43:04'),
(4, 4, 'in Process', 'Product ready for Shipping', '2017-03-10 19:50:36'),
(5, 44, 'in Process', 'In progress', '2020-10-19 12:06:41'),
(6, 44, 'Delivered', 'delivered', '2020-10-19 12:07:25'),
(7, 45, 'in Process', 'qwaesdrfgh', '2020-10-19 12:16:55'),
(8, 45, 'Delivered', 'asdfv', '2020-10-19 12:17:02'),
(9, 59, 'Delivered', 'this is delivered', '2020-10-20 05:41:57'),
(10, 74, 'Delivered', 'this is Deliver', '2020-10-27 10:11:29'),
(11, 103, 'Delivered', 'delivered', '2020-10-28 07:38:53'),
(12, 115, 'Delivered', 'Delivered', '2020-10-30 08:31:02'),
(13, 100, 'Delivered', 'po', '2020-11-04 05:37:03'),
(14, 128, 'in Process', 'deliver soon', '2020-11-04 05:41:09');

-- --------------------------------------------------------

--
-- Table structure for table `partners`
--

CREATE TABLE `partners` (
  `id` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `partners`
--

INSERT INTO `partners` (`id`, `title`, `image`) VALUES
(10, 'Greenville', 'logo01.png'),
(11, 'Arizona', 'logo02.png'),
(12, 'Dressmakers', 'logo04 (1).png'),
(13, 'Wedly & co', 'logo03.png');

-- --------------------------------------------------------

--
-- Table structure for table `payment_ledger`
--

CREATE TABLE `payment_ledger` (
  `pay_id` int(11) NOT NULL,
  `payment_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `signature_hash` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `privacy_policy`
--

CREATE TABLE `privacy_policy` (
  `id` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content` varchar(1000) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `privacy_policy`
--

INSERT INTO `privacy_policy` (`id`, `title`, `content`) VALUES
(1, 'Privacy Policy test', '<p>This is <em><strong>privacy policy</strong></em> content for testing and confirmation. test</p>');

-- --------------------------------------------------------

--
-- Table structure for table `productreviews`
--

CREATE TABLE `productreviews` (
  `id` int(11) NOT NULL,
  `productId` int(11) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `summary` varchar(255) DEFAULT NULL,
  `review` longtext,
  `reviewDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `productreviews`
--

INSERT INTO `productreviews` (`id`, `productId`, `quality`, `price`, `value`, `name`, `summary`, `review`, `reviewDate`) VALUES
(2, 3, 4, 5, 5, 'Anuj Kumar', 'BEST PRODUCT FOR ME :)', 'BEST PRODUCT FOR ME :)', '2017-02-26 20:43:57'),
(3, 3, 3, 4, 3, 'Sarita pandey', 'Nice Product', 'Value for money', '2017-02-26 20:52:46'),
(4, 3, 3, 4, 3, 'Sarita pandey', 'Nice Product', 'Value for money', '2017-02-26 20:59:19');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `subCategory` int(11) DEFAULT NULL,
  `productName` varchar(255) DEFAULT NULL,
  `productCompany` varchar(255) DEFAULT NULL,
  `productPrice` int(11) DEFAULT NULL,
  `productPriceBeforeDiscount` int(11) DEFAULT NULL,
  `productDescription` longtext,
  `duration` varchar(1000) NOT NULL,
  `addInfo` varchar(1000) NOT NULL,
  `returns` varchar(1000) NOT NULL,
  `productImage1` varchar(255) DEFAULT NULL,
  `productImage2` varchar(255) DEFAULT NULL,
  `productImage3` varchar(255) DEFAULT NULL,
  `productImage4` varchar(255) DEFAULT NULL,
  `productAvailability` varchar(255) DEFAULT NULL,
  `postingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(255) DEFAULT NULL,
  `razorpay_multiply` int(11) NOT NULL,
  `shippingCharge` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category`, `subCategory`, `productName`, `productCompany`, `productPrice`, `productPriceBeforeDiscount`, `productDescription`, `duration`, `addInfo`, `returns`, `productImage1`, `productImage2`, `productImage3`, `productImage4`, `productAvailability`, `postingDate`, `updationDate`, `razorpay_multiply`, `shippingCharge`) VALUES
(187, 57, 42, 'This is Gemstone', '', 5599, 6000, '<p>&nbsp;</p>\r\n<p>test test more&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>test test more&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>test test more&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>test test more&nbsp;</p>', '', '<p>This is test 3 This is test 3 This is test 3 This is test 3&nbsp;</p>', '', '11.jpg', '12.jpg', '9.jpg', '3.png', 'In Stock', '2020-10-28 07:23:24', NULL, 100, 0),
(191, 54, 34, 'Dwimukhi Rudraksh', 'Gurudevo.in', 1599, 2000, '                                    test', '                                    test', '                                    test', '                                    test', '2.jpg', '2 - Copy.jpg', '2.png', '3.jpeg', 'In Stock', '2020-10-28 10:33:48', NULL, 100, 0),
(192, 54, 38, 'Ekmukhi Rudraksh', 'Gurudevo.in', 2599, 3000, '                                    TEST', '                                    TEST', '                                    TEST', '                                    TEST', '7.jpg', '4 - Copy.jpg', '6.jpg', '5.jpg', 'In Stock', '2020-10-28 10:37:37', NULL, 100, 0),
(195, 54, 34, '5 Mukhi Rudraksha', '', 559, 1000, '<p>4 Mukhi Rudraksha is represented by Lord Brahma, The Creator of Universe. Lord Brahma has 4 Heads which represents 4 different level of knowledge. It helps the wearer in realizing the four level of knowledge represented by Jagrit (waking), Swapna (dreaming), Sushupati (deep sleep), Turiya (super conscious state of consciousness). Hence, the energy of lord brahma helps the wearer to attain knowledge and wisdom. 4 Mukni Rudraksha broadens the mind and helps the wearer to be more creative. The wearer of this bead will have inclination towards spirituality, meditation and insight &amp; removes the darkness of ignorance. This bead also helps in removing intellectual dullness.&nbsp;<br />\r\nBenefits:<br />\r\nThis bead is highly beneficial for students, scholars, teacher, writers, journalists and researchers.<br />\r\nIt helps the wearer to be more organized in his/her thinking, expression, behavior and communication.<br />\r\nIt helps in providing the 4 different level of knowledge represented by Jagrit, Swapna, Sushpati, &amp; Turiya.<br />\r\nIt makes the wearer logical, intelligent and most important it broadens his/her mind. &nbsp;<br />\r\nIt is very good for respiratory system and sore throats.&nbsp;</p>\r\n', '', '                                    ', '                                    ', '5F Back Pic.jpg', '5F Back Pic.png', '5F Front Pic.jpg', '5F Front Pic.png', 'In Stock', '2020-10-30 09:31:00', NULL, 100, 0),
(209, 54, 34, 'test', '', 299, 300, '<h1><em><strong><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">5 Mukhi Rudraksha</span></strong></em></h1>\r\n<p><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">[32] Sed ut perspiciatis, unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam eaque ipsa, quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt, explicabo. Nemo enim ipsam voluptatem, quia voluptas sit, aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos, qui ratione voluptatem sequi nesciunt, neque porro quisquam est, qui do</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">lorem ipsum</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">, quia&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">dolor sit amet consectetur adipisci[ng]</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">v</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">elit, sed</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">&nbsp;quia non numquam&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">[do] eius mod</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">i&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">tempor</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">a&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">inci[di]dunt, ut labore et dolore magna</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">m&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">aliqua</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">m quaerat voluptatem.&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">Ut enim ad minim</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">a&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">veniam, quis nostru</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">m</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">[d] exercitation</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">em&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">ullam co</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">rporis suscipit&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">labori</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">o</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">s</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">am,&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">nisi ut aliquid ex ea commod</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">i&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">consequat</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">ur?&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">Quis aute</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">m vel eum&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">iure reprehenderit,</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">&nbsp;qui&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">in</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">&nbsp;ea&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">voluptate velit esse</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">, quam nihil molestiae&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">c</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">onsequatur, vel&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">illum</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">, qui&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">dolore</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">m&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">eu</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">m&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">fugiat</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">, quo voluptas&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">nulla pariatur</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">? [33] At vero eos et accusamus et iusto odio dignissimos ducimus, qui blanditiis praesentium voluptatum deleniti atque corrupti, quos dolores et quas molestias&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">exceptur</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">i&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">sint, obcaecat</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">i&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">cupiditat</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">e&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">non pro</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">v</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">ident</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">, similique&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">sunt in culpa</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">,&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">qui officia deserunt mollit</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">ia&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">anim</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">i,&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">id est laborum</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">&nbsp;et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat&hellip;</span></p>', '', '<h1><em><strong><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">5 Mukhi Rudraksha Info</span></strong></em></h1>\r\n<p><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">[32] Sed ut perspiciatis, unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam eaque ipsa, quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt, explicabo. Nemo enim ipsam voluptatem, quia voluptas sit, aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos, qui ratione voluptatem sequi nesciunt, neque porro quisquam est, qui do</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">lorem ipsum</u><span style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color: #ffffff;\">, quia&nbsp;</span><u style=\"color: #202122; font-family: sans-serif; font-size: 14px; background-color', '', '5F Front Pic.png', '', '', '', 'In Stock', '2020-10-31 06:26:49', NULL, 100, 0),
(210, 54, 34, 'tes', '', 100, 100, '<h3><em><strong>This is test content for testing and confirmation.</strong></em></h3>\r\n<p style=\"padding-left: 40px;\"><em>1. This is test content for testing and confirmation.</em></p>\r\n<p style=\"padding-left: 40px;\"><em>2. This is test content for testing and confirmation.</em></p>\r\n<p style=\"padding-left: 40px;\"><em>3. This is test content for testing and confirmation.</em></p>\r\n<p style=\"padding-left: 40px;\"><em>4. This is test content for testing and confirmation.</em></p>\r\n<p style=\"padding-left: 40px;\"><em>5. This is test content for testing and confirmation.</em></p>\r\n<p style=\"padding-left: 40px;\"><em>6. This is test content for testing and confirmation.</em></p>\r\n<p style=\"padding-left: 40px;\"><em>7. This is test content for testing and confirmation.</em></p>\r\n<p style=\"padding-left: 40px;\"><em>8. This is test content for testing and confirmation.&nbsp;</em></p>', '', '<p style=\"padding-left: 40px;\"><em>1. This is test content for testing and confirmation.</em></p>\r\n<p style=\"padding-left: 40px;\"><em>2. This is test content for testing and confirmation.</em></p>\r\n<p style=\"padding-left: 40px;\"><em>3. This is test content for testing and confirmation.</em></p>\r\n<p style=\"padding-left: 40px;\"><em>4. This is test content for testing and confirmation.</em></p>\r\n<p style=\"padding-left: 40px;\"><em>5. This is test content for testing and confirmation.</em></p>\r\n<p style=\"padding-left: 40px;\"><em>6. This is test content for testing and confirmation.</em></p>\r\n<p style=\"padding-left: 40px;\"><em>7. This is test content for testing and confirmation.</em></p>\r\n<p style=\"padding-left: 40px;\"><em>8. This is test content for testing and confirmation.&nbsp;</em></p>', '', '', '', '', '', 'In Stock', '2020-11-03 06:12:56', NULL, 100, 0),
(211, 54, 34, 'de,o', '', 1, 1, '<p><strong>bgb</strong></p>\r\n<p>jkk</p>', '', '<p><strong>bgb</strong></p>\r\n<p>jkk</p>', '', '4F Front 1.png', '', '', '', 'In Stock', '2020-11-03 06:25:10', NULL, 100, 0),
(212, 57, 42, 'test', '', 155, 200, '<p>This is test product descritption. This is test product descritption. This is test product descritption. This is test product descritption. This is test product descritption. This is test product descritption.&nbsp;</p>', '', '<p>This is test product descritption. This is test product descritption. This is test product descritption. This is test product descritption. This is test product descritption. This is test product descritption. This is test product descritption.&nbsp;</p>', '', '8.jpg', '', '', '', 'In Stock', '2020-11-05 05:54:35', NULL, 100, 0),
(213, 57, 42, 'test', '', 155, 200, '<p>This is test product descritption. This is test product descritption. This is test product descritption. This is test product descritption. This is test product descritption. This is test product descritption.&nbsp;</p>', '', '<p>This is test product descritption. This is test product descritption. This is test product descritption. This is test product descritption. This is test product descritption. This is test product descritption. This is test product descritption.&nbsp;</p>', '', '8.jpg', '', '', '', 'In Stock', '2020-11-05 05:55:40', NULL, 100, 0),
(214, 57, 42, 'test2', '', 150, 300, '<p style=\"padding-left: 40px;\"><em>This is product description for testing and confirmation.</em></p>\r\n<p style=\"padding-left: 40px;\"><em> This is product description for testing and confirmation. </em></p>\r\n<p style=\"padding-left: 40px;\"><em>This is product description for testing and confirmation. </em></p>\r\n<p style=\"padding-left: 40px;\"><em>This is product description for testing and confirmation. </em></p>\r\n<p style=\"padding-left: 40px;\"><em>This is product description for testing and confirmation. </em></p>\r\n<p style=\"padding-left: 40px;\"><em>This is product description for testing and confirmation.&nbsp;</em></p>', '', '<p>This is product description for testing and confirmation. This is product description for testing and confirmation. This is product description for testing and confirmation. This is product description for testing and confirmation. This is product description for testing and confirmation. This is product description for testing and confirmation.&nbsp;</p>', '', 'about.png', '', '', '', 'In Stock', '2020-11-05 05:59:23', NULL, 100, 0),
(215, 57, 42, 'test2', '', 150, 300, '<p>This is product description for testing and confirmation. This is product description for testing and confirmation. This is product description for testing and confirmation. This is product description for testing and confirmation. This is product description for testing and confirmation. This is product description for testing and confirmation.&nbsp;</p>', '', '<p>This is product description for testing and confirmation. This is product description for testing and confirmation. This is product description for testing and confirmation. This is product description for testing and confirmation. This is product description for testing and confirmation. This is product description for testing and confirmation.&nbsp;</p>', '', 'Kundali.jpg', '', '', '', 'In Stock', '2020-11-05 06:18:47', NULL, 100, 0),
(216, 58, 39, 'test', 'test', 499, 600, '<p>This is test Description for testing</p>', '', '', '', '3.jpeg', '4 - Copy.jpg', '11.jpg', NULL, 'In Stock', '2020-11-05 06:36:05', NULL, 0, 0),
(217, 58, 41, 'test 3', '', 259, 300, '<p>This is test description.&nbsp;</p>', '', '<p>This is test description.&nbsp;</p>', '', '13.jpg', '3.jpg', '2.png', '2.jpg', 'In Stock', '2020-11-05 06:41:21', NULL, 100, 0);

-- --------------------------------------------------------

--
-- Table structure for table `return_policy`
--

CREATE TABLE `return_policy` (
  `id` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content` varchar(1000) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `return_policy`
--

INSERT INTO `return_policy` (`id`, `title`, `content`) VALUES
(1, 'Return Policy test', '<p>This is <em><strong>Return Policy </strong></em>for testing and confirmation.</p>');

-- --------------------------------------------------------

--
-- Table structure for table `social_media`
--

CREATE TABLE `social_media` (
  `id` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(1000) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `social_media`
--

INSERT INTO `social_media` (`id`, `title`, `url`) VALUES
(1, 'facebook', 'this is facebook'),
(2, 'twitter', 'test test'),
(4, 'linkedin', 'tsdfasdf'),
(5, 'youtube-play', 'asdf'),
(6, 'instagram', 'asdf'),
(7, 'skype', 'asdf');

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `id` int(11) NOT NULL,
  `categoryid` int(11) DEFAULT NULL,
  `subcategory` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`id`, `categoryid`, `subcategory`, `creationDate`, `updationDate`) VALUES
(32, 18, 'asdfasdf', '2020-10-12 07:30:11', NULL),
(34, 54, 'Nepali Rudraksh', '2020-10-16 11:19:01', '28-10-2020 04:46:00 PM'),
(35, 48, 'Today Gemstone', '2020-10-16 11:19:16', NULL),
(36, 55, 'Original Rudraksh', '2020-10-16 11:47:52', NULL),
(37, 54, 'Indonasian Rudraksh', '2020-10-16 12:56:52', '28-10-2020 04:04:55 PM'),
(38, 54, 'Rameshwaram Rudraksh', '2020-10-16 12:57:15', '28-10-2020 04:05:14 PM'),
(39, 58, 'Lakshmi Yantram', '2020-10-19 10:57:03', NULL),
(40, 58, 'Om Yantram', '2020-10-19 10:57:20', NULL),
(41, 58, 'ShivYantram', '2020-10-19 10:57:41', NULL),
(42, 57, 'First Gemstone ', '2020-10-19 11:52:59', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `id` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `sub_title` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `title_2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content` varchar(10000) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`id`, `title`, `sub_title`, `title_2`, `content`, `image`) VALUES
(1, 'test title test', 'test sub titletest', 'test title 2test', '<div class=\"hs_about_heading_wrapper text-center\" style=\"box-sizing: border-box; text-align: center; float: left; width: 1370px; display: inline-block; color: #797979; font-family: Roboto, sans-serif; font-size: 16px; background-color: #ffffff;\">\r\n<p style=\"box-sizing: border-box; margin: 0px 0px 1.1em; color: #444444; font-size: 18px; line-height: 32.4px; text-align: start; text-transform: none; border: 0px; padding: 0px; overflow-wrap: break-word;\">Gemini is termed as&nbsp;<em style=\"box-sizing: border-box; border: 0px; font-family: inherit; line-height: 1; margin: 0px; padding: 0px;\">Twins</em>. Mercury the lord of the sign is depicted as a boy, among all gods, not fully grown still in his teens. In the ancient symbolic pictures, The twins were brothers and sisters. Mercury is also said to be the&nbsp;<strong style=\"box-sizing: border-box;\">&rdquo; winged messenger of the god</strong>&nbsp;<strong style=\"box-sizing: border-box; margin-bottom: 0px;\">&ldquo;.&nbsp;</strong>Mercury has both wings on its helmet and also sandals. That is why Geminians are very quick It is said that people with some important and big things to express, generally elect the time of Gemini as they have faith that this sign will give sharp intelligence, adaptability and ultimately grand success.</p>\r\n<p style=\"box-sizing: border-box; margin: 0px 0px 1.1em; color: #444444; font-size: 18px; line-height: 32.4px; text-align: start; text-transform: none; border: 0px; padding: 0px; overflow-wrap: break-word;\"><img class=\"alignnone size-full wp-image-423\" style=\"box-sizing: border-box; border: 0px; vertical-align: middle; font-family: inherit; line-height: 1; margin: 0px; padding: 0px; height: auto; max-width: 100%;\" src=\"https://gautamnaman.files.wordpress.com/2017/10/1d90af01d02ff2a0b58dd4aee6d7cb43.jpg?w=736\" sizes=\"(max-width: 736px) 100vw, 736px\" srcset=\"https://gautamnaman.files.wordpress.com/2017/10/1d90af01d02ff2a0b58dd4aee6d7cb43.jpg?w=736 736w, https://gautamnaman.files.wordpress.com/2017/10/1d90af01d02ff2a0b58dd4aee6d7cb43.jpg?w=150 150w, https://gautamnaman.files.wordpress.com/2017/10/1d90af01d02ff2a0b58dd4aee6d7cb43.jpg?w=300 300w, https://gautamnaman.files.wordpress.com/2017/10/1d90af01d02ff2a0b58dd4aee6d7cb43.jpg?w=768 768w, https://gautamnaman.files.wordpress.com/2017/10/1d90af01d02ff2a0b58dd4aee6d7cb43.jpg?w=1024 1024w, https://gautamnaman.files.wordpress.com/2017/10/1d90af01d02ff2a0b58dd4aee6d7cb43.jpg 1402w\" alt=\"1d90af01d02ff2a0b58dd4aee6d7cb43\" data-attachment-id=\"423\" data-permalink=\"https://gautamnaman.wordpress.com/2017/10/23/gemini-mitunam/1d90af01d02ff2a0b58dd4aee6d7cb43/\" data-orig-file=\"https://gautamnaman.files.wordpress.com/2017/10/1d90af01d02ff2a0b58dd4aee6d7cb43.jpg\" data-orig-size=\"1402,1068\" data-comments-opened=\"1\" data-image-meta=\"{&quot;aperture&quot;:&quot;0&quot;,&quot;credit&quot;:&quot;&quot;,&quot;camera&quot;:&quot;&quot;,&quot;caption&quot;:&quot;&quot;,&quot;created_timestamp&quot;:&quot;0&quot;,&quot;copyright&quot;:&quot;&quot;,&quot;focal_length&quot;:&quot;0&quot;,&quot;iso&quot;:&quot;0&quot;,&quot;shutter_speed&quot;:&quot;0&quot;,&quot;title&quot;:&quot;&quot;,&quot;orientation&quot;:&quot;0&quot;}\" data-image-title=\"1d90af01d02ff2a0b58dd4aee6d7cb43\" data-image-description=\"\" data-medium-file=\"https://gautamnaman.files.wordpress.com/2017/10/1d90af01d02ff2a0b58dd4aee6d7cb43.jpg?w=300\" data-large-file=\"https://gautamnaman.files.wordpress.com/2017/10/1d90af01d02ff2a0b58dd4aee6d7cb43.jpg?w=736\" /></p>\r\n<p style=\"box-sizing: border-box; margin: 0px 0px 1.1em; color: #444444; font-size: 18px; line-height: 32.4px; text-align: start; text-transform: none; border: 0px; padding: 0px; overflow-wrap: break-word;\">Being a common sign and the third sign of the zodiac, these people will have a liking towards travel frequently. These may be mainly short journeys by land. They are always active with facile mind. One of the basic characteristic of Geminians is that before taking the decision the tend to consider the advantages and disadvantages of the case then only proceed further, they never haste in decision making.</p>\r\n<h4 style=\"box-sizing: border-box; font-weight: 400; line-height: 1.1; color: #222222; margin: 0px; font-size: 18px; padding: 10px 0px 30px 30px;\">&nbsp;</h4>\r\n</div>\r\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; color: #535353; font-size: 15px; line-height: 28px; font-family: Roboto, sans-serif; background-color: #ffffff;\">&nbsp;</p>\r\n<p>&nbsp;</p>', '');

-- --------------------------------------------------------

--
-- Table structure for table `testimonial`
--

CREATE TABLE `testimonial` (
  `id` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `sub_title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `testimonial`
--

INSERT INTO `testimonial` (`id`, `title`, `sub_title`, `content`, `image`) VALUES
(10, 'John', 'Web Developer', 'This is very amazing company', 'online1.jpg'),
(11, 'Anand Kumar', 'Web Developer', 'This is testimonial for Gurudevo.in . Thanks a log Gurudevo.in.', 'news_img1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(11) NOT NULL,
  `userEmail` varchar(255) DEFAULT NULL,
  `userip` binary(16) DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `logout` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `userEmail`, `userip`, `loginTime`, `logout`, `status`) VALUES
(73, 'other@gmail.com', 0x3130362e3231352e3131362e38300000, '2020-10-24 08:35:14', '24-10-2020 02:08:06 PM', 1),
(78, 'other@gmail.com', 0x3138322e37372e32352e353600000000, '2020-10-27 10:10:41', NULL, 1),
(79, 'other@gmail.com', 0x3138322e37372e32352e353600000000, '2020-10-27 10:29:24', NULL, 0),
(80, 'other@gmail.com', 0x3138322e37372e32352e353600000000, '2020-10-27 10:29:35', NULL, 1),
(81, 'other@gmail.com', 0x3138322e37372e32352e353600000000, '2020-10-27 10:30:31', '27-10-2020 04:01:35 PM', 1),
(82, 'other@gmail.com', 0x3138322e37372e32352e353600000000, '2020-10-27 10:38:54', NULL, 1),
(83, 'other@gmail.com', 0x3138322e37372e32352e353600000000, '2020-10-27 10:49:19', '27-10-2020 04:22:07 PM', 1),
(84, 'other@gmail.com', 0x3138322e37372e32352e353600000000, '2020-10-27 10:52:30', '27-10-2020 04:25:25 PM', 1),
(85, 'other@gmail.com', 0x3138322e37372e32352e353600000000, '2020-10-27 10:55:38', NULL, 0),
(86, 'other@gmail.com', 0x3138322e37372e32352e353600000000, '2020-10-27 10:55:52', NULL, 0),
(87, 'other@gmail.com', 0x3138322e37372e32352e353600000000, '2020-10-27 10:56:03', NULL, 1),
(88, 'other@gmail.com', 0x3138322e37372e32352e353600000000, '2020-10-27 11:58:31', NULL, 1),
(89, 'other@gmail.com', 0x3130332e39352e3132322e3832000000, '2020-10-27 16:07:43', NULL, 1),
(90, 'other@gmail.com', 0x3138322e37372e32352e353600000000, '2020-10-28 06:42:38', '28-10-2020 12:56:45 PM', 1),
(91, 'other@gmail.com', 0x3138322e37372e32352e353600000000, '2020-10-28 07:27:21', NULL, 1),
(92, 'other@gmail.com', 0x3138322e37372e32352e353600000000, '2020-10-28 07:44:48', NULL, 1),
(93, 'other@gmail.com', 0x3138322e37372e32352e353600000000, '2020-10-28 08:41:40', '28-10-2020 02:18:41 PM', 1),
(94, 'TEST@GMAIL.COM', 0x3138322e37372e32352e353600000000, '2020-10-28 08:49:45', NULL, 1),
(95, 'other@gmail.com', 0x3138322e37372e32352e353600000000, '2020-10-28 10:57:17', NULL, 1),
(96, 'other@gmail.com', 0x3138322e37372e32352e353600000000, '2020-10-28 11:39:24', NULL, 1),
(97, 'other@gmail.com', 0x3137312e37382e3232322e3132350000, '2020-10-30 08:22:42', NULL, 1),
(98, 'other@gmail.com', 0x3137312e37382e3232322e3132350000, '2020-10-30 11:14:13', NULL, 1),
(99, 'other@gmail.com', 0x3130332e31332e3130352e3134300000, '2020-10-30 15:27:58', NULL, 1),
(100, 'other@gmail.com', 0x34372e33302e3137352e313532000000, '2020-10-31 13:48:20', '31-10-2020 07:19:14 PM', 1),
(101, 'other@gmail.com', 0x3132322e3136312e3130372e36310000, '2020-11-04 05:31:45', '04-11-2020 11:07:43 AM', 1),
(102, 'anildev@gmail.com', 0x3132322e3136312e3130372e36310000, '2020-11-04 05:39:09', NULL, 1),
(103, 'other@gmail.com', 0x3132322e3136312e3130372e36310000, '2020-11-05 05:26:08', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contactno` bigint(11) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `shippingAddress` longtext,
  `shippingState` varchar(255) DEFAULT NULL,
  `shippingCity` varchar(255) DEFAULT NULL,
  `shippingPincode` int(11) DEFAULT NULL,
  `billingAddress` longtext,
  `billingState` varchar(255) DEFAULT NULL,
  `billingCity` varchar(255) DEFAULT NULL,
  `billingPincode` int(11) DEFAULT NULL,
  `regDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `contactno`, `password`, `shippingAddress`, `shippingState`, `shippingCity`, `shippingPincode`, `billingAddress`, `billingState`, `billingCity`, `billingPincode`, `regDate`, `updationDate`) VALUES
(1, 'Anuj Kumar', 'anuj.lpu1@gmail.com', 9009857868, 'f925916e2754e5e03f75dd58a5733251', 'CS New Delhi', 'New Delhi', 'Delhi', 110001, 'New Delhi', 'New Delhi', 'Delhi', 110092, '2017-02-04 19:30:50', ''),
(2, 'Amit ', 'amit@gmail.com', 8285703355, '5c428d8875d2948607f3e3fe134d71b4', '', '', '', 0, '', '', '', 0, '2017-03-15 17:21:22', ''),
(3, 'hg', 'hgfhgf@gmass.com', 1121312312, '827ccb0eea8a706c4c34a16891f84e7b', '', '', '', 0, '', '', '', 0, '2018-04-29 09:30:32', ''),
(4, 'Test2', 'test2@gamil.com', 3331331321, 'e10adc3949ba59abbe56e057f20f883e', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-08-31 10:27:42', NULL),
(5, 'Ak', 'anandtechmarketz@gmail.com', 1234567890, '81dc9bdb52d04dc20036dbd8313ed055', 'Hf fu', 'Ggghhhh', 'Hhhhjv', 0, NULL, NULL, NULL, NULL, '2020-09-04 03:09:40', NULL),
(6, 'afdf', 'abc@gmail.com', 123546, '536f868c09cfbc81399401da424e42e6', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-09-07 09:52:41', NULL),
(7, 'Mr. Anand', 'other@gmail.com', 235345452, 'caf1a3dfb505ffed0d024130f58c5cfa', 'test test', 'test test', 'test t5rest', 2345, 'test test', 'test test', 'test test ', 2345, '2020-10-12 10:05:19', NULL),
(8, 'Hello Astro', 'helloastro@gmail.com', 321321, 'e10adc3949ba59abbe56e057f20f883e', 'asdf', 'asdf', 'asdf', 2374, 'asdf', 'asdf', 'asdf', 2541, '2020-10-14 05:22:44', NULL),
(9, 'Khem Lal', 'lalkhem@gmail.com', 2345, 'e10adc3949ba59abbe56e057f20f883e', 'asdf', 'asdf', 'asdf', 0, 'adsf', 'asdf', 'asdf', 0, '2020-10-14 07:32:09', NULL),
(10, 'khem chand', 'khemchandv510@gmail.com', 8826767918, 'e10adc3949ba59abbe56e057f20f883e', 'sdfsd\r\nsfdsdf', 'Delhi', 'sdfds', 110043, NULL, NULL, NULL, NULL, '2020-10-19 12:14:04', NULL),
(11, 'Aman Kumar', 'aman@gmail.com', 1234567890, '202cb962ac59075b964b07152d234b70', 'test test ', 'test test', 'tes test', 0, 'test test', 'test test', 'test test', 0, '2020-10-22 05:10:44', NULL),
(12, 'Tejram Paswan', 'tejramtrp@gmail.com', 8318242407, '629bf38255370d89e52b3b898acfe614', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-10-24 06:23:31', NULL),
(13, 'TETS', 'TEST@GMAIL.COM', 123, '202cb962ac59075b964b07152d234b70', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-10-28 08:49:27', NULL),
(14, 'anildev', 'anildev@gmail.com', 7894563210, '731309c4bb223491a9f67eac5214fb2e', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-04 05:38:47', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `wallet_package`
--

CREATE TABLE `wallet_package` (
  `id` int(11) NOT NULL,
  `time_1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `package_1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `time_2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `package_2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `time_3` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `package_3` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `time_4` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `package_4` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `wallet_package`
--

INSERT INTO `wallet_package` (`id`, `time_1`, `package_1`, `time_2`, `package_2`, `time_3`, `package_3`, `time_4`, `package_4`) VALUES
(2, '15 Minutes', '1000', '30 Minutes', '1500', '45 Minutes', '200', '1 Hour', '200');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `productId` int(11) DEFAULT NULL,
  `postingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`id`, `userId`, `productId`, `postingDate`) VALUES
(1, 1, 0, '2017-02-27 18:53:17'),
(3, 5, 37, '2020-09-05 11:49:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about_us`
--
ALTER TABLE `about_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `about_why`
--
ALTER TABLE `about_why`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `astro_service`
--
ALTER TABLE `astro_service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `experience`
--
ALTER TABLE `experience`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `experts`
--
ALTER TABLE `experts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `footer`
--
ALTER TABLE `footer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `home_banner`
--
ALTER TABLE `home_banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `home_card`
--
ALTER TABLE `home_card`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `horoscope`
--
ALTER TABLE `horoscope`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `how_work`
--
ALTER TABLE `how_work`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `know_about_2`
--
ALTER TABLE `know_about_2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ordertrackhistory`
--
ALTER TABLE `ordertrackhistory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `partners`
--
ALTER TABLE `partners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_ledger`
--
ALTER TABLE `payment_ledger`
  ADD PRIMARY KEY (`pay_id`);

--
-- Indexes for table `privacy_policy`
--
ALTER TABLE `privacy_policy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `productreviews`
--
ALTER TABLE `productreviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `return_policy`
--
ALTER TABLE `return_policy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `social_media`
--
ALTER TABLE `social_media`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonial`
--
ALTER TABLE `testimonial`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wallet_package`
--
ALTER TABLE `wallet_package`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about_us`
--
ALTER TABLE `about_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `about_why`
--
ALTER TABLE `about_why`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `astro_service`
--
ALTER TABLE `astro_service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `experience`
--
ALTER TABLE `experience`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `experts`
--
ALTER TABLE `experts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `faq`
--
ALTER TABLE `faq`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `footer`
--
ALTER TABLE `footer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `home_banner`
--
ALTER TABLE `home_banner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `home_card`
--
ALTER TABLE `home_card`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `horoscope`
--
ALTER TABLE `horoscope`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `how_work`
--
ALTER TABLE `how_work`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `know_about_2`
--
ALTER TABLE `know_about_2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=130;

--
-- AUTO_INCREMENT for table `ordertrackhistory`
--
ALTER TABLE `ordertrackhistory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `partners`
--
ALTER TABLE `partners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `payment_ledger`
--
ALTER TABLE `payment_ledger`
  MODIFY `pay_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `privacy_policy`
--
ALTER TABLE `privacy_policy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `productreviews`
--
ALTER TABLE `productreviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=218;

--
-- AUTO_INCREMENT for table `return_policy`
--
ALTER TABLE `return_policy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `social_media`
--
ALTER TABLE `social_media`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `subcategory`
--
ALTER TABLE `subcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `test`
--
ALTER TABLE `test`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `testimonial`
--
ALTER TABLE `testimonial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `wallet_package`
--
ALTER TABLE `wallet_package`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
