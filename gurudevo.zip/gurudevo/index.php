<?php
session_start();
error_reporting(0);
include('db/conn.php');
?>
<?php include 'header.php' ?>
<!-- hs Slider Start -->
<div class="slider-area">
   <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
      <div class="carousel-inner" role="listbox">
      
      <?php $sql=mysqli_query($con,"select * from home_banner where id=2");
                                                        while($row=mysqli_fetch_array($sql))
                                                        {
                                                            ?>

         <div class="item active">
            <div class="carousel-captions caption-1" style="background-image : url('panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['image']);?>')">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                        <div class="content">
                           <h1 data-animation="animated bounceInLeft"><img src="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['image2']);?>" alt="slider_logo" /></h1>
                           <h2 data-animation="animated zoomInDown"> <span> <?php echo htmlentities($row['title']);?> </span></h2>
                           <p data-animation="animated bounceInUp"><?php echo $row['content'] ?></p>
                           <div class="hs_effect_btn">
                              <ul>
                                 <li data-animation="animated flipInX"><a href="#" class="hs_btn_hover">Read more</a></li>
                              </ul>
                           </div>
                           <div class="clear"></div>
                        </div>
                     </div>
                     <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 hidden-sm hidden-xs">
                        <div class="content_tabs">
                           <div class="row">
                              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                 <div class="hs_slider_right_tabs_wrapper" data-animation="animated bounceInLeft hs_slider_tab_one">
                                    <div class="hs_slider_tabs_icon_wrapper">
                                       <i class="fa fa-<?php echo htmlentities($row['icon_1']);?>"></i>
                                    </div>
                                    <div class="hs_slider_tabs_icon_cont_wrapper">
                                       <ul>
                                          <li><a href="#" class="hs_tabs_btn"><?php echo htmlentities($row['point_1']);?></a></li>
                                       </ul>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                 <div class="hs_slider_right_tabs_wrapper hs_slider_right_tabs_wrapper2" data-animation="animated bounceInRight hs_slider_tab_tow">
                                    <div class="hs_slider_tabs_icon_wrapper">
                                    <i class="fa fa-<?php echo htmlentities($row['icon_2']);?>"></i>
                                    </div>
                                    <div class="hs_slider_tabs_icon_cont_wrapper">
                                       <ul>
                                       <li><a href="#" class="hs_tabs_btn"><?php echo htmlentities($row['point_2']);?></a></li>
                                       </ul>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                 <div class="hs_slider_right_tabs_wrapper hs_slider_right_tabs_wrapper2" data-animation="animated bounceInLeft hs_slider_tab_three">
                                    <div class="hs_slider_tabs_icon_wrapper">
                                    <i class="fa fa-<?php echo htmlentities($row['icon_3']);?>"></i>
                                    </div>
                                    <div class="hs_slider_tabs_icon_cont_wrapper">
                                       <ul>
                                       <li><a href="#" class="hs_tabs_btn"><?php echo htmlentities($row['point_3']);?></a></li>
                                       </ul>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                 <div class="hs_slider_right_tabs_wrapper hs_slider_right_tabs_wrapper2" data-animation="animated bounceInRight hs_slider_tab_four">
                                    <div class="hs_slider_tabs_icon_wrapper">
                                    <i class="fa fa-<?php echo htmlentities($row['icon_4']);?>"></i>
                                    </div>
                                    <div class="hs_slider_tabs_icon_cont_wrapper">
                                       <ul>
                                       <li><a href="#" class="hs_tabs_btn"><?php echo htmlentities($row['point_4']);?></a></li>
                                       </ul>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                 <div class="hs_slider_right_tabs_wrapper hs_slider_right_tabs_wrapper2" data-animation="animated bounceInLeft hs_slider_tab_fifth">
                                    <div class="hs_slider_tabs_icon_wrapper">
                                    <i class="fa fa-<?php echo htmlentities($row['icon_5']);?>"></i>
                                    </div>
                                    <div class="hs_slider_tabs_icon_cont_wrapper">
                                       <ul>
                                       <li><a href="#" class="hs_tabs_btn"><?php echo htmlentities($row['point_5']);?></a></li>
                                       </ul>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
                                                        <?php } ?>

                                                        <?php $sql=mysqli_query($con,"select * from home_banner where id=3");
                                                        while($row=mysqli_fetch_array($sql))
                                                        {
                                                            ?>

         <div class="item">
            <div class="carousel-captions caption-2" style="background-image : url('panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['image']);?>')">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                        <div class="content">
                           <h1 data-animation="animated bounceInLeft"><img src="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['image2']);?>" alt="slider_logo" /></h1>
                           <h2 data-animation="animated zoomInDown"> <span> <?php echo htmlentities($row['title']);?> </span></h2>
                           <p data-animation="animated bounceInUp"><?php echo $row['content'] ?></p>
                           <div class="hs_effect_btn">
                              <ul>
                                 <li data-animation="animated flipInX"><a href="#" class="hs_btn_hover">Read more</a></li>
                              </ul>
                           </div>
                           <div class="clear"></div>
                        </div>
                     </div>
                     <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 hidden-sm hidden-xs">
                        <div class="content_tabs">
                           <div class="row">
                              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                 <div class="hs_slider_right_tabs_wrapper" data-animation="animated bounceInLeft hs_slider_tab_one">
                                    <div class="hs_slider_tabs_icon_wrapper">
                                       <i class="fa fa-<?php echo htmlentities($row['icon_1']);?>"></i>
                                    </div>
                                    <div class="hs_slider_tabs_icon_cont_wrapper">
                                       <ul>
                                          <li><a href="#" class="hs_tabs_btn"><?php echo htmlentities($row['point_1']);?></a></li>
                                       </ul>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                 <div class="hs_slider_right_tabs_wrapper hs_slider_right_tabs_wrapper2" data-animation="animated bounceInRight hs_slider_tab_tow">
                                    <div class="hs_slider_tabs_icon_wrapper">
                                    <i class="fa fa-<?php echo htmlentities($row['icon_2']);?>"></i>
                                    </div>
                                    <div class="hs_slider_tabs_icon_cont_wrapper">
                                       <ul>
                                       <li><a href="#" class="hs_tabs_btn"><?php echo htmlentities($row['point_2']);?></a></li>
                                       </ul>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                 <div class="hs_slider_right_tabs_wrapper hs_slider_right_tabs_wrapper2" data-animation="animated bounceInLeft hs_slider_tab_three">
                                    <div class="hs_slider_tabs_icon_wrapper">
                                    <i class="fa fa-<?php echo htmlentities($row['icon_3']);?>"></i>
                                    </div>
                                    <div class="hs_slider_tabs_icon_cont_wrapper">
                                       <ul>
                                       <li><a href="#" class="hs_tabs_btn"><?php echo htmlentities($row['point_3']);?></a></li>
                                       </ul>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                 <div class="hs_slider_right_tabs_wrapper hs_slider_right_tabs_wrapper2" data-animation="animated bounceInRight hs_slider_tab_four">
                                    <div class="hs_slider_tabs_icon_wrapper">
                                    <i class="fa fa-<?php echo htmlentities($row['icon_4']);?>"></i>
                                    </div>
                                    <div class="hs_slider_tabs_icon_cont_wrapper">
                                       <ul>
                                       <li><a href="#" class="hs_tabs_btn"><?php echo htmlentities($row['point_4']);?></a></li>
                                       </ul>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                 <div class="hs_slider_right_tabs_wrapper hs_slider_right_tabs_wrapper2" data-animation="animated bounceInLeft hs_slider_tab_fifth">
                                    <div class="hs_slider_tabs_icon_wrapper">
                                    <i class="fa fa-<?php echo htmlentities($row['icon_5']);?>"></i>
                                    </div>
                                    <div class="hs_slider_tabs_icon_cont_wrapper">
                                       <ul>
                                       <li><a href="#" class="hs_tabs_btn"><?php echo htmlentities($row['point_5']);?></a></li>
                                       </ul>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
                                                        <?php } ?>


         <ol class="carousel-indicators">
            <li data-target="#carousel-example-generic" data-slide-to="0" class="active"><span class="number"></span></li>
            <li data-target="#carousel-example-generic" data-slide-to="1" class=""><span class="number"></span></li>
            <li data-target="#carousel-example-generic" data-slide-to="2" class=""><span class="number"></span></li>
         </ol>
         <div class="carousel-nevigation">
            <a class="prev" href="#carousel-example-generic" role="button" data-slide="prev">
            <i class="fa fa-angle-left"></i>
            <span>PREV</span>
            </a>
            <a class="next" href="#carousel-example-generic" role="button" data-slide="next">
            <span>NEXT</span>
            <i class="fa fa-angle-right"></i>
            </a>
         </div>
      </div>
   </div>
</div>
<!-- hs Slider End -->
<!-- hs title wrapper Start -->
<div class="hs_title_main_wrapper">
   <div class="container">
      <div class="row">
      <?php $sql=mysqli_query($con,"select id,title,sub_title,content,image  from home_card");
                                    while($row=mysqli_fetch_array($sql))
                                    {
                                       ?>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
               <div class="hs_title_box_main_wrapper">
                  <div class="hs_title_img_wrapper">
                     <img src="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['image']);?>" alt="totle_img">
                  </div>
                     <div class="hs_title_img_cont_wrapper">
                           <h2><a href="#"><?php echo $row['title'] ?> </a></h2>
                           <p><?php echo $row['sub_title'] ?></p>
                           <h5><a href="#" data-toggle="modal" data-target="#<?php echo htmlentities($row['id']);?>">Read More <i class="fa fa-long-arrow-right"></i></a></h5>
                                    <!-- Modal -->
                           <div class="modal fade" id="<?php echo htmlentities($row['id']);?>" tabindex="-1" role="dialog" aria-labelledby="<?php echo htmlentities($row['id']);?>" aria-hidden="true">
                              <div class="modal-dialog modal-dialog-centered" role="document">
                                 <div class="modal-content-area">
                                    <div class="modal-header">
                                       <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                          <span aria-hidden="true">&times;</span>
                                       </button>
                                    </div>
                                    <div class="">
                                          <p><?php echo $row['content'] ?></p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                     </div>
               </div>
            </div>
         <?php } ?>
         
      </div>
   </div>
</div>
<!-- hs title wrapper End -->

<!-- hs sign wrapper Start -->
<div class="hs_sign_main_wrapper">
   <div class="container">
      <div class="hs_sign_heading_wrapper">
         <div class="hs_about_heading_main_wrapper">
            <div class="hs_about_heading_wrapper text-center">
               <h2>Choose Your <span>Zodiac Sign</span></h2>
               <h4><span></span></h4>
               <p>Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum<br> auctor, nisi elit consequat hello Aenean world.</p>
            </div>
         </div>
      </div>
      <div class="hs_sign_center_wrapper visible-xs visible-sm">
         <div class="hs_cycle_main_wrapper">
            <div class="hs_cycle_img">
               <img src="images/cycle.jpg" alt="circle_img">
               <span class="pulse"></span>
               <div class="hs_tab_shap1">
                  <a href="#">
                     <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-taurus"></i></p>
                  </a>
               </div>
               <div class="hs_tab_shap2">
                  <a href="daily_horoscope.php">
                     <svg version="1.1" id="Layer_2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-aries"></i></p>
                  </a>
               </div>
               <div class="hs_tab_shap3">
                  <a href="#">
                     <svg version="1.1" id="Layer_3" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-libra"></i></p>
                  </a>
               </div>
               <div class="hs_tab_shap4">
                  <a href="#">
                     <svg version="1.1" id="Layer_4" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-scorpio"></i></p>
                  </a>
               </div>
               <div class="hs_tab_shap5">
                  <a href="#">
                     <svg version="1.1" id="Layer_5" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-leo"></i></p>
                  </a>
               </div>
               <div class="hs_tab_shap6">
                  <a href="#">
                     <svg version="1.1" id="Layer_6" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-capricorn"></i></p>
                  </a>
               </div>
               <div class="hs_tab_shap7">
                  <a href="#">
                     <svg version="1.1" id="Layer_7" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-aquarius"></i></p>
                  </a>
               </div>
               <div class="hs_tab_shap8">
                  <a href="#">
                     <svg version="1.1" id="Layer_8" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-gemini-zodiac-sign-symbol"></i></p>
                  </a>
               </div>
               <div class="hs_tab_shap9">
                  <a href="#">
                     <svg version="1.1" id="Layer_9" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-virgo"></i></p>
                  </a>
               </div>
               <div class="hs_tab_shap10">
                  <a href="#">
                     <svg version="1.1" id="Layer_10" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-leo"></i></p>
                  </a>
               </div>
               <div class="hs_tab_shap11">
                  <a href="#">
                     <svg version="1.1" id="Layer_11" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-cancer"></i></p>
                  </a>
               </div>
               <div class="hs_tab_shap12">
                  <a href="#">
                     <svg version="1.1" id="Layer_12" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-gemini-zodiac-sign-symbol"></i></p>
                  </a>
               </div>
            </div>
         </div>
      </div>
      
    
      <div class="hs_sign_left_wrapper">
         <div class="row">
   
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <div class="hs_sign_left_tabs_wrapper hs_sign_left_tabs_border_wrapper1">
                  <div class="hs_slider_tabs_icon_wrapper">
                     <i class="flaticon-aries"></i>
                  </div>
                  <div class="hs_slider_tabs_icon_cont_wrapper">
                     <ul>
                        <li><a href="daily_horoscope.php?id=1" class="hs_tabs_btn">Aries</a></li>
                     </ul>
                  </div>
                  <span></span>
               </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <div class="hs_sign_left_tabs_wrapper hs_sign_left_tabs_wrapper_2 hs_sign_left_tabs_border_wrapper2">
                  <div class="hs_slider_tabs_icon_wrapper">
                     <i class="flaticon-taurus"></i>
                  </div>
                  <div class="hs_slider_tabs_icon_cont_wrapper">
                     <ul>
                        <li><a href="daily_horoscope.php?id=2" class="hs_tabs_btn">Taurus</a></li>
                     </ul>
                  </div>
                  <span></span>
               </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <div class="hs_sign_left_tabs_wrapper hs_sign_left_tabs_wrapper_2 hs_sign_left_tabs_border_wrapper3">
                  <div class="hs_slider_tabs_icon_wrapper">
                     <i class="flaticon-gemini-zodiac-sign-symbol"></i>
                  </div>
                  <div class="hs_slider_tabs_icon_cont_wrapper">
                     <ul>
                        <li><a href="daily_horoscope.php?id=3" class="hs_tabs_btn">Gemini</a></li>
                     </ul>
                  </div>
                  <span></span>
               </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <div class="hs_sign_left_tabs_wrapper hs_sign_left_tabs_wrapper_2 hs_sign_left_tabs_border_wrapper4">
                  <div class="hs_slider_tabs_icon_wrapper">
                     <i class="flaticon-cancer"></i>
                  </div>
                  <div class="hs_slider_tabs_icon_cont_wrapper">
                     <ul>
                        <li><a href="daily_horoscope.php?id=4" class="hs_tabs_btn">Cancer</a></li>
                     </ul>
                  </div>
                  <span></span>
               </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <div class="hs_sign_left_tabs_wrapper hs_sign_left_tabs_wrapper_2 hs_sign_left_tabs_border_wrapper5">
                  <div class="hs_slider_tabs_icon_wrapper">
                     <i class="flaticon-leo"></i>
                  </div>
                  <div class="hs_slider_tabs_icon_cont_wrapper">
                     <ul>
                        <li><a href="daily_horoscope.php?id=5" class="hs_tabs_btn">Leo</a></li>
                     </ul>
                  </div>
                  <span></span>
               </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <div class="hs_sign_left_tabs_wrapper hs_sign_left_tabs_wrapper_2 hs_sign_left_tabs_border_wrapper6">
                  <div class="hs_slider_tabs_icon_wrapper">
                     <i class="flaticon-virgo"></i>
                  </div>
                  <div class="hs_slider_tabs_icon_cont_wrapper">
                     <ul>
                        <li><a href="daily_horoscope.php?id=6" class="hs_tabs_btn">Virgo</a></li>
                     </ul>
                  </div>
                  <span></span>
               </div>
            </div>
         </div>
      </div>
      <div class="hs_sign_right_wrapper visible-xs">
         <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <div class="hs_sign_left_tabs_wrapper hs_sign_right_tabs_border_wrapper1">
                  <span></span>
                  <div class="hs_slider_tabs_icon_wrapper">
                     <i class="flaticon-libra"></i>
                  </div>
                  <div class="hs_slider_tabs_icon_cont_wrapper">
                     <ul>
                        <li><a href="daily_horoscope.php?id=7" class="hs_tabs_btn">Libra</a></li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <div class="hs_sign_left_tabs_wrapper hs_sign_left_tabs_wrapper_2 hs_sign_right_tabs_border_wrapper2">
                  <span></span>
                  <div class="hs_slider_tabs_icon_wrapper">
                     <i class="flaticon-scorpio"></i>
                  </div>
                  <div class="hs_slider_tabs_icon_cont_wrapper">
                     <ul>
                        <li><a href="daily_horoscope.php?id=8" class="hs_tabs_btn">Scorpio</a></li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <div class="hs_sign_left_tabs_wrapper hs_sign_left_tabs_wrapper_2 hs_sign_right_tabs_border_wrapper3">
                  <span></span>
                  <div class="hs_slider_tabs_icon_wrapper">
                     <i class="flaticon-leo"></i>
                  </div>
                  <div class="hs_slider_tabs_icon_cont_wrapper">
                     <ul>
                        <li><a href="daily_horoscope.php?id=9" class="hs_tabs_btn">Sagittairus
                           </a>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <div class="hs_sign_left_tabs_wrapper hs_sign_left_tabs_wrapper_2 hs_sign_right_tabs_border_wrapper4">
                  <span></span>
                  <div class="hs_slider_tabs_icon_wrapper">
                     <i class="flaticon-capricorn"></i>
                  </div>
                  <div class="hs_slider_tabs_icon_cont_wrapper">
                     <ul>
                        <li><a href="daily_horoscope.php?id=10" class="hs_tabs_btn">
                           Capricorn
                           </a>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <div class="hs_sign_left_tabs_wrapper hs_sign_left_tabs_wrapper_2 hs_sign_right_tabs_border_wrapper5">
                  <span></span>
                  <div class="hs_slider_tabs_icon_wrapper">
                     <i class="flaticon-aquarius"></i>
                  </div>
                  <div class="hs_slider_tabs_icon_cont_wrapper">
                     <ul>
                        <li><a href="daily_horoscope.php?id=11" class="hs_tabs_btn">
                           Aquarius
                           </a>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <div class="hs_sign_left_tabs_wrapper hs_sign_left_tabs_wrapper_2 hs_sign_right_tabs_border_wrapper6">
                  <span></span>
                  <div class="hs_slider_tabs_icon_wrapper">
                     <i class="flaticon-gemini-zodiac-sign-symbol"></i>
                  </div>
                  <div class="hs_slider_tabs_icon_cont_wrapper">
                     <ul>
                        <li><a href="daily_horoscope.php?id=12" class="hs_tabs_btn">Pisces
                           </a>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="hs_sign_center_wrapper hidden-sm hidden-xs">
         <div class="hs_cycle_main_wrapper">
            <div class="hs_cycle_img">
               <img src="images/cycle.jpg" alt="circle_img">
               <span class="pulse"></span>
               <div class="hs_tab_shap1">
                  <a href="#">
                     <svg version="1.1" id="Layer_13" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-taurus"></i></p>
                  </a>
               </div>
               <div class="hs_tab_shap2">
                  <a href="#">
                     <svg version="1.1" id="Layer_14" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-aries"></i></p>
                  </a>
               </div>
               <div class="hs_tab_shap3">
                  <a href="#">
                     <svg version="1.1" id="Layer_15" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-libra"></i></p>
                  </a>
               </div>
               <div class="hs_tab_shap4">
                  <a href="#">
                     <svg version="1.1" id="Layer_16" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-scorpio"></i></p>
                  </a>
               </div>
               <div class="hs_tab_shap5">
                  <a href="#">
                     <svg version="1.1" id="Layer_17" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-leo"></i></p>
                  </a>
               </div>
               <div class="hs_tab_shap6">
                  <a href="#">
                     <svg version="1.1" id="Layer_18" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-capricorn"></i></p>
                  </a>
               </div>
               <div class="hs_tab_shap7">
                  <a href="#">
                     <svg version="1.1" id="Layer_19" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-aquarius"></i></p>
                  </a>
               </div>
               <div class="hs_tab_shap8">
                  <a href="#">
                     <svg version="1.1" id="Layer_20" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-gemini-zodiac-sign-symbol"></i></p>
                  </a>
               </div>
               <div class="hs_tab_shap9">
                  <a href="#">
                     <svg version="1.1" id="Layer_21" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-virgo"></i></p>
                  </a>
               </div>
               <div class="hs_tab_shap10">
                  <a href="#">
                     <svg version="1.1" id="Layer_22" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-leo"></i></p>
                  </a>
               </div>
               <div class="hs_tab_shap11">
                  <a href="#">
                     <svg version="1.1" id="Layer_23" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-cancer"></i></p>
                  </a>
               </div>
               <div class="hs_tab_shap12">
                  <a href="#">
                     <svg version="1.1" id="Layer_24" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="68.811px" height="64.729px" viewBox="0 0 68.811 64.729" enable-background="new 0 0 68.811 64.729" xml:space="preserve">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0,52.763c0,0,26.125,0.367,42.664,11.967l26.147-46.796
                           c0,0-30.278-18.234-68.054-17.929L0,52.763z"/>
                     </svg>
                     <p><i class="flaticon-gemini-zodiac-sign-symbol"></i></p>
                  </a>
               </div>
            </div>
         </div>
      </div>
      <div class="hs_sign_right_wrapper hidden-xs">
         <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <div class="hs_sign_left_tabs_wrapper hs_sign_right_tabs_border_wrapper1">
                  <span></span>
                  <div class="hs_slider_tabs_icon_cont_wrapper">
                     <ul>
                        <li><a href="daily_horoscope.php?id=7" class="hs_tabs_btn">Libra</a></li>
                     </ul>
                  </div>
                  <div class="hs_slider_tabs_icon_wrapper">
                     <i class="flaticon-libra"></i>
                  </div>
               </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <div class="hs_sign_left_tabs_wrapper hs_sign_left_tabs_wrapper_2 hs_sign_right_tabs_border_wrapper2">
                  <span></span>
                  <div class="hs_slider_tabs_icon_cont_wrapper">
                     <ul>
                        <li><a href="daily_horoscope.php?id=8" class="hs_tabs_btn">Scorpio</a></li>
                     </ul>
                  </div>
                  <div class="hs_slider_tabs_icon_wrapper">
                     <i class="flaticon-scorpio"></i>
                  </div>
               </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <div class="hs_sign_left_tabs_wrapper hs_sign_left_tabs_wrapper_2 hs_sign_right_tabs_border_wrapper3">
                  <span></span>
                  <div class="hs_slider_tabs_icon_cont_wrapper">
                     <ul>
                        <li><a href="daily_horoscope.php?id=9" class="hs_tabs_btn">Sagittairus</a></li>
                     </ul>
                  </div>
                  <div class="hs_slider_tabs_icon_wrapper">
                     <i class="flaticon-leo"></i>
                  </div>
               </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <div class="hs_sign_left_tabs_wrapper hs_sign_left_tabs_wrapper_2 hs_sign_right_tabs_border_wrapper4">
                  <span></span>
                  <div class="hs_slider_tabs_icon_cont_wrapper">
                     <ul>
                        <li><a href="daily_horoscope.php?id=10" class="hs_tabs_btn">Capricorn</a></li>
                     </ul>
                  </div>
                  <div class="hs_slider_tabs_icon_wrapper">
                     <i class="flaticon-capricorn"></i>
                  </div>
               </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <div class="hs_sign_left_tabs_wrapper hs_sign_left_tabs_wrapper_2 hs_sign_right_tabs_border_wrapper5">
                  <span></span>
                  <div class="hs_slider_tabs_icon_cont_wrapper">
                     <ul>
                        <li><a href="daily_horoscope.php?id=11" class="hs_tabs_btn">Aquarius</a></li>
                     </ul>
                  </div>
                  <div class="hs_slider_tabs_icon_wrapper">
                     <i class="flaticon-aquarius"></i>
                  </div>
               </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <div class="hs_sign_left_tabs_wrapper hs_sign_left_tabs_wrapper_2 hs_sign_right_tabs_border_wrapper6">
                  <span></span>
                  <div class="hs_slider_tabs_icon_cont_wrapper">
                     <ul>
                        <li><a href="daily_horoscope.php?id=12" class="hs_tabs_btn">Pisces</a></li>
                     </ul>
                  </div>
                  <div class="hs_slider_tabs_icon_wrapper">
                     <i class="flaticon-gemini-zodiac-sign-symbol"></i>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- hs sign wrapper End -->
<!-- Include Astrologer Services  -->
<?php include '_astro_talk.php' ?>
<!-- Include Astrologer Services  -->


<div id="how-it-works" class="about1 waves padding-t-80">
   <div class="container">
      <div class="row">
         <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="hs_about_heading_main_wrapper">
               <div class="hs_about_heading_wrapper text-center">
                  <h2>How <span> it Works</span></h2>
                  <h4><span></span></h4>
                  <p>Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum<br> auctor, nisi elit consequat hello Aenean world.</p>
               </div>
            </div>
         </div>
         <div class="col-md-6 slider_how_to_it">
            <div id="sync1" class="owl-carousel owl-theme">

               <?php $sql=mysqli_query($con,"select * from how_work");
                  while($row=mysqli_fetch_array($sql))
                  { ?>
               <div class="item">
                  <div class="home1_one">
                     <img src="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['image']);?>"   alt=""   class="img-responsive lazy phone_img">
                     <div class="man-wearing"> <img src="images/man-wearing-blue-button-up-top-pointing-png-clip-art.png" class="img-responsive">
                     </div>
                  </div>
               </div>

            <?php } ?> 

            </div>
         </div>
         <div class="col-md-6">
            <div id="sync2" class="owl-carousel owl-theme">
            <?php $sql=mysqli_query($con,"select * from how_work where id=3");
                  while($row=mysqli_fetch_array($sql))
                  { ?>
               <div class="item item1">
                  <div class="slider_text">
                
                     <h2><?php echo $row['title'] ?> </h2>
                     <p><?php echo $row['sub_title'] ?></p>
                
                  </div>
               </div>
               <?php } ?>
               <?php $sql=mysqli_query($con,"select * from how_work where id=4");
                  while($row=mysqli_fetch_array($sql))
                  { ?>
               <div class="item item2">
                  <div class="slider_text">

                     <h2><?php echo $row['title'] ?> </h2>
                     <p><?php echo $row['sub_title'] ?></p>

                  </div>
               </div>
                  <?php } ?>
                  <?php $sql=mysqli_query($con,"select * from how_work where id=5");
                  while($row=mysqli_fetch_array($sql))
                  { ?>
               <div class="item item3">
                  <div class="slider_text">
                     <h2><?php echo $row['title'] ?> </h2>
                     <p><?php echo $row['sub_title'] ?></p>
                  </div>
               </div>
                  <?php } ?>
                  <?php $sql=mysqli_query($con,"select * from how_work where id=6");
                  while($row=mysqli_fetch_array($sql))
                  { ?>
               <div class="item item4">
                  <div class="slider_text">
                     <h2><?php echo $row['title'] ?> </h2>
                     <p>
                     <?php echo $row['sub_title'] ?>
                     </p>
                  </div>
               </div>
                  <?php } ?>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- hs How to It  wrapper End -->
<div class="hs_blog_categories_main_wrapper shop-pages">

<div class="container">

            <div class="hs_blog_left_sidebar_main_wrapper">

                <div class="row">

                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

                     <div class="hs_shop_tabs_cont_sec_wrapper text-center">

                        <div class="hs_about_heading_wrapper text-center">
                              <h2> OUR <span> CATEGORIES</span></h2>
                              <h4><span></span></h4>
                        </div>

                        <div class="tab-content">

                           <div id="home" class="tab-pane fade in active">

                                 <div class="row">
                                 <?php $sql=mysqli_query($con,"select id,categoryName,image  from category");
                                    while($row=mysqli_fetch_array($sql))
                                    {
                                       ?>
                                    

                                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                       <div class="hs_shop_prodt_main_box">
                                             <div class="hs_shop_prodt_img_wrapper category_img">
                                             <img  src="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['image']);?>" alt="shop_product">

                                                <a href="shop_list.php?cid=<?php echo $row['id'];?>"  class="accordion-toggle collapsed">
                                                <?php echo $row['categoryName'];?>
                                                </a>
                                             </div>
                                       </div>
                                    </div>

                                    <?php } ?>


                                 </div>

                           </div>

                        </div>

                     </div>

                  </div>

                </div>

            </div>

        </div>

</div>

<!-- hs Shop now wrapper Start -->

<!-- hs Shop now wrapper End -->
<?php include 'experience.php' ?>

<!-- hs testi slider wrapper Start -->
<div class="hs_testi_slider_main_wrapper">
   <div class="container">
      <div class="row">
         <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="hs_about_heading_main_wrapper">
               <div class="hs_about_heading_wrapper text-center">
                  <h2>What clients <span> are saying</span></h2>
                  <h4><span></span></h4>
               </div>
            </div>
         </div>
         <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="hs_testi_slider_wrapper">
               <div class="owl-carousel owl-theme">
               <?php $sql=mysqli_query($con,"select * from testimonial");
                                                        while($row=mysqli_fetch_array($sql))
                                                        {
                                                            ?>
                  <div class="item">
                     <div class="row">
                        <div class="col-12">
                           <div class="hs_testi_cont_main_wrapper">
                              <div class="hs_testi_cont_inner_wrapper">
                                 <div class="hs_testi_quote_wrapper">
                                    <i class="fa fa-quote-left"></i>
                                 </div>
                                 <div class="hs_testi_quote_cont_wrapper">
                                    <p><?php echo $row['content'];?></p>
                                 </div>
                              </div>
                           </div>
                           <div class="hs_testi_client_main_wrapper">
                              <div class="hs_testi_client_cont_sec">
                                 <h2><?php echo $row['sub_title'] ?></h2>
                                 <p><?php echo $row['title'] ?></p>
                              </div>
                              <div class="hs_testi_client_cont_img_sec">
                                 <img src="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['image']);?>" alt="Testimonial Image">

                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <?php } ?>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- hs testi slider wrapper End -->
<!-- hs advert wrapper Start -->
<div class="hs_advert_main_wrapper">
   <div class="hs_advert_img_overlay"></div>
   <div class="container">
      <div class="row">
         <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="hs_advert_cont_wrapper">
               <h1>STOP SELF-SABOTAGE: USING<br> THE ZODIAC TO GET YOUR LIFE BACK ON TRACK</h1>
               <p>Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec<br> sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris.</p>
               <div class="hs_effect_btn hs_advert_btn_wrapper">
                  <ul>
                     <li><a href="#" class="hs_btn_hover">Read more</a></li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- hs advert wrapper End -->

<!-- hs client slider wrapper Start -->
<?php include 'partners.php' ?>
<!-- hs client slider wrapper End -->
<!-- hs online slider wrapper Start -->
<?php include 'experts.php' ?>
<!-- hs online slider wrapper End -->

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- Modal-End -->  
<?php include 'footer.php' ?>