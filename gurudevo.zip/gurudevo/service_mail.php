<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    extract($_POST);
    $to      = 'dev@techmarketz.in';
    $subject = 'Service query from Gurudevo.com';
    $message = 'Name: ' . $name . "\r\n";
    $message = 'Phone: ' . $phone . "\r\n";
    $message .= 'Email: ' . $email . "\r\n";
    $message .= 'Date of Birth: ' . $dob . "\r\n";
    $message .= 'Time of Birth: ' . $tob . "\r\n";
    $message .= 'Place: ' . $place . "\r\n";
    $headers = 'From: info@techmarketz.com' . "\r\n" .
        'Reply-To: domain@example.com' . "\r\n" .
        'X-Mailer: PHP/' . phpversion();
    if (mail($to, $subject, $message, $headers)) {
        $_SESSION['msg'] = "Swal.fire(
                        'Mail Sent Successfully',
                        'We will contact you soon',
                        'success'
                        )";
    } else {
        $_SESSION['msg'] = "Swal.fire(
                        'Error While Sending Mail',
                        'Please try again',
                        'error'
                        )";
    }
}
