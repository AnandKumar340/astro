<?php 
session_start();
error_reporting(0);
include('db/conn.php');
$id=intval($_GET['cid']);
if(isset($_GET['action']) && $_GET['action']=="add"){
	$id=intval($_GET['id']);
	if(isset($_SESSION['cart'][$id])){
		$_SESSION['cart'][$id]['quantity']++;
	}else{
		$sql_p="SELECT * FROM products WHERE id={$id}";
		$query_p=mysqli_query($con,$sql_p);
		if(mysqli_num_rows($query_p)!=0){
			$row_p=mysqli_fetch_array($query_p);
			$_SESSION['cart'][$row_p['id']]=array("quantity" => 1, "price" => $row_p['productPrice']);
					echo "<script>alert('Product has been added to the cart')</script>";
		echo "<script type='text/javascript'> document.location ='my-cart.php'; </script>";
		}else{
			$message="Product ID is invalid";
		}
	}
}
$pid=intval($_GET['pid']);
if(isset($_GET['pid']) && $_GET['action']=="wishlist" ){
	if(strlen($_SESSION['login'])==0)
    {   
header('location:login.php');
}
else
{
mysqli_query($con,"insert into wishlist(userId,productId) values('".$_SESSION['id']."','$pid')");
echo "<script>alert('Product aaded in wishlist');</script>";
header('location:my-wishlist.php');

}
}
if(isset($_POST['submit']))
{
	$qty=$_POST['quality'];
	$price=$_POST['price'];
	$value=$_POST['value'];
	$name=$_POST['name'];
	$summary=$_POST['summary'];
	$review=$_POST['review'];
	mysqli_query($con,"insert into productreviews(productId,quality,price,value,name,summary,review) values('$pid','$qty','$price','$value','$name','$summary','$review')");
}


?>
<?php include 'header.php' ?>
<div class="clearfix"></div>

<div class="breadcrumb">
	<div class="container">
		<div class="breadcrumb-inner">
			<ul class="list-inline list-unstyled">
				<li> <b> <a href="index.php">Home </a></b></li> / 
                <li> <b> <a href="shop.php">Shop </a></b></li> /
                <?php $sql=mysqli_query($con,"select subcategory from subcategory where id='$cid'");
                     while($row=mysqli_fetch_array($sql))
                     { ?>
				<li class='active'><?php echo htmlentities($row['subcategory']);?></li>
                <?php } ?>







                <?php  $ret=mysqli_query($con,"select * from products where id='$pid'");
while($row=mysqli_fetch_array($ret))
{ ?>
				<li class='active'><?php echo htmlentities($row['productName']);?></li>
                <?php } ?>
			</ul>
		</div><!-- /.breadcrumb-inner -->
	</div><!-- /.container -->
</div><!-- /.breadcrumb -->


<!-- magnific start -->
<?php  $ret=mysqli_query($con,"select * from products where id='$pid'");
while($row=mysqli_fetch_array($ret))
{ ?>
<section id="magnific" class="product-detail">
   <div class="container">
      <div class="row">

         <div class="col-sm-12 col-md-5">
            <div class="large-5 column product-zoomss">
               <img class="xzoom5" id="xzoom-magnific" src="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage1']);?>" xoriginal="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage1']);?>" />
               <div class="xzoom-thumbs">
               
               <a href="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage1']);?>"><img class="xzoom-gallery5" width="80" src="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage1']);?>"  xpreview="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage1']);?>" title=""></a>

                  <a href="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage2']);?>"><img class="xzoom-gallery5" width="80" src="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage2']);?>"  xpreview="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage2']);?>" title=""></a>

                  <a href="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage3']);?>"><img class="xzoom-gallery5" width="80" src="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage3']);?>"  xpreview="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage3']);?>" title=""></a>

                  <a href="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage4']);?>"><img class="xzoom-gallery5" width="80" src="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage4']);?>"  xpreview="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage4']);?>" title=""></a>

               </div>
            </div>
         </div>

         <div class="large-7 column"></div>
         <div class="col-sm-12 col-md-7">
            <div class="product-text">
               <h3><?php echo htmlentities($row['productName']);?>
               </h3>

             
               <hr>
              
               <div class="clearfix"></div>
         
               <!--Listing-->
               <section class="detailslisting">
                  <div class="row">
                     <div class="col-md-12">
                        <div class="detailslistingbox">
                           <ul class="dlbul">
                              <li><i class="fa fa-play"></i> Product Availability : <?php echo htmlentities($row['productAvailability']);?></li>
                              <li><i class="fa fa-play"></i> Product Price : <span class="discount-mrp"> MRP: <del><i class="fa fa-inr" aria-hidden="true"></i> <?php echo htmlentities($row['productPriceBeforeDiscount']);?></del></span></li>
                              <li><i class="fa fa-play"></i> Discount Price : <i class="fa fa-inr"></i> <?php echo htmlentities($row['productPrice']);?></strong></li>
                              <li><i class="fa fa-play"></i> Shipping Charge : <span class="value">Extra,  According to Your Destination </span></li>
                           
                           </ul>
                        </div>
                     </div>
                  </div>
               </section>
               <!--Listing-->
               <div class="clearfix"></div>
              
               <hr>

               <div class="quantity-container info-container">
								<div class="row">
									
									<div class="col-sm-2">
										<span class="label">Quantity :</span>
									</div>
								</div><!-- /.row -->
							</div><!-- /.quantity-container -->
               <div class="quantity clearfix">
                  <div class="qty mt-5 col-md-12">
                     <b class="pull-left text-uppercase" style="">Quantity : </b>
                     <input type="number" name="quantity" id="59" value="1" min="1" max="6" class="form-control-quality">
                  </div>
                  <div class="row">
                     <div class="qty mt-5 col-md-12" id="addbutton">
                     <?php if($row['productAvailability']=='In Stock'){?>
										   <a href="shop_details.php?page=product&action=add&id=<?php echo $row['id']; ?>" class="btn btn-primary"><i class="fa fa-shopping-cart inner-right-vs"></i> ADD TO CART</a>
													<?php } else {?>
							               <div class="action" style="color:red">Out of Stock</div>
					               <?php } ?>         
                     </div>
                  </div>
               </div>
            </div>
            <div id="cart_count">
            </div>
         </div>
      </div>
   </div>
</section>

<!-- magnific end -->
<div class="description-tabs">
   <div class="container">
      <div class="row">
         <div class="col-sm-12">
            <div class="txtb">
               <div class="tabs">
                  <input type="radio" id="tab1" name="tab-control" checked>
                  <input type="radio" id="tab2" name="tab-control">
                
                  <ul>
                     <li><label for="tab1" role="button"><span>Description</span></label></li>
                     <li><label for="tab2" role="button"><span>Additional Information</span></label></li>
                  </ul>
                  <div class="slider">
                     <div class="indicator"></div>
                  </div>
                  <div class="content">
                     <section class="description-detailss">
                        <div class="row">
                           <div class="col-md-3">
                              <img  src="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage1']);?>">
                           </div>
                           <div class="col-md-9">
                              <?php echo $row['productDescription'] ?>

                           </div>
                        </div>
                     </section>

                 
                     <section>
                     <?php echo $row['addInfo'] ?>
                     </section>

                    
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $cid=$row['category'];
			$subcid=$row['subCategory']; } ?>


         <?php include 'partners.php' ?>    
  
      <?php include 'experts.php' ?>   
       
<!-- hs footer wrapper Start -->
<div class="hs_footer_main_wrapper">
   <div class="container">
      <div class="row">
         <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">

            <div class="hs_footer_logo_wrapper">
            <?php $sql=mysqli_query($con,"select * from footer where id=1");
                  while($row=mysqli_fetch_array($sql))
                  { ?>
               <img src="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['image']);?>" alt="footer_logo" class="img-responsive" />
               <p><?php echo $row['content'] ?></p>
               <!-- <h4><a href="about_us.php">Read More <i class="fa fa-long-arrow-right"></i></a></h4> -->

                  <?php } ?>
               <ul>
               <?php $sql=mysqli_query($con,"select * from social_media");
                  while($row=mysqli_fetch_array($sql))
                  { ?>
                  <li><a href="<?php echo $row['url'] ?>"><i class="fa fa-<?php echo $row['title'] ?>"></i></a></li>

                  <?php } ?>
               </ul>
            </div>
         </div>
         <?php $sql=mysqli_query($con,"select * from footer where id=2");
                  while($row=mysqli_fetch_array($sql))
                  { ?>
         <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
            <div class="hs_footer_help_wrapper">
               <h2><?php echo $row['title'] ?></h2>
               <p><?php echo $row['content'] ?></p>
               <div class="hs_footer_help_btn">
                  <ul>
                     <li><a href="about_us.php" class="hs_btn_hover">Free Quote</a></li>
                  </ul>
               </div>
            </div>
         </div>
                  <?php } ?>
               
         <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
            <div class="hs_footer_contact_wrapper">
            <h2> Useful Links </h2>
               <ul>
              <li class="useful_link"><a href="blog.php"> Blogs </a></li>
              <li class="useful_link"><a href="privacy_policy.php"> Privacy Policy </a></li>
              <li class="useful_link"><a href="return_policy.php"> Return Policy </a></li>
              <li class="useful_link"><a href="faq.php"> FAQ </a></li>
              </ul>
               <!-- <div class="hs_footer_contact_input_wrapper">
                  <input type="text" placeholder="Email Address..."><i class="fa fa-envelope"></i>
               </div> -->
            </div>
         </div>
                 
      </div>
   </div>
</div>
<!-- hs footer wrapper End -->
<!-- Whatsapp icon  -->
<a href="https://api.whatsapp.com/send?phone=918800773063" class="whatsapp" target="_blank"><i class="fa fa-whatsapp" aria-hidden="true"></i></a>
<!-- whatsapp icon  -->
<!-- hs footer wrapper End -->
<!-- hs bottom footer wrapper Start -->
<div class="hs_bottom_footer_main_wrapper">
   <a href="javascript:" id="return-to-top"><i class="fa fa-angle-up"></i></a>
   <div class="container">
      <div class="row">
         <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="footer_bottom_cont_wrapper">
               <p>  Copyright | Designed and Developed by :  <a href="http://www.techmarketz.com/" target="_blank">Techmarketz.com</a> </p>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- hs bottom footer wrapper End -->
<!--main js file start-->
<script src="js/jquery_min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/modernizr.js"></script>
<script src="js/mainhomef195.js"></script>
<script src="js/jquery.menu-aim.js"></script>
<script src="js/parallax.min.js"></script>
<script src="js/owl.carousel.js"></script>
<script src="js/jquery.shuffle.min.js"></script>
<script src="js/jquery.countTo.js"></script>
<script src="js/jquery.inview.min.js"></script>
<script src="js/jquery.magnific-popup.js"></script>
<script src="js/custom.js"></script>
<!--main js file end-->
<!-- zoom product -->
<script type="text/javascript" src="js/xzoom.min.js"></script>
<!-- <script src="js/vendor/modernizr.js"></script>
   <script src="js/vendor/jquery.js"></script> -->
<script src="js/foundation.min.js"></script>
<script src="js/setup.js"></script>
<script>
   $(document).ready(function() {
   
   
   
       var sync1 = $("#sync1");
   
       var sync2 = $("#sync2");
   
       var slidesPerPage = 4; //globaly define number of elements per page
   
       var syncedSecondary = true;
   
   
   
       sync1.owlCarousel({
   
           items: 1,
   
           slideSpeed: 2000,
   
           nav: false,
   
           autoplay: true,  
   
            autoplayTimeout:50000 ,
   
           dots: false,
   
           loop: true,
   
           responsiveRefreshRate: 200,
   
           navText: ['<svg width="100%" height="100%" viewBox="0 0 11 20"><path style="fill:none;stroke-width: 1px;stroke: #000;" d="M9.554,1.001l-8.607,8.607l8.607,8.606"/></svg>', '<svg width="100%" height="100%" viewBox="0 0 11 20" version="1.1"><path style="fill:none;stroke-width: 1px;stroke: #000;" d="M1.054,18.214l8.606,-8.606l-8.606,-8.607"/></svg>'],
   
       }).on('changed.owl.carousel', syncPosition);
   
   
   
       sync2
   
           .on('initialized.owl.carousel', function() {
   
               sync2.find(".owl-item").eq(0).addClass("current");
   
           })
   
           .owlCarousel({
   
               items: slidesPerPage,
   
               dots: false,
   
               nav: false,
   
               smartSpeed: 200,
   
               slideSpeed: 500,
   
               slideBy: slidesPerPage, //alternatively you can slide by 1, this way the active slide will stick to the first item in the second carousel
   
               responsiveRefreshRate: 100
   
           }).on('changed.owl.carousel', syncPosition2);
   
   
   
       function syncPosition(el) {
   
           //if you set loop to false, you have to restore this next line
   
           //var current = el.item.index;
   
   
   
           //if you disable loop you have to comment this block
   
           var count = el.item.count - 1;
   
           var current = Math.round(el.item.index - (el.item.count / 2) - .5);
   
   
   
           if (current < 0) {
   
               current = count;
   
           }
   
           if (current > count) {
   
               current = 0;
   
           }
   
   
   
           //end block
   
   
   
           sync2
   
               .find(".owl-item")
   
               .removeClass("current")
   
               .eq(current)
   
               .addClass("current");
   
           var onscreen = sync2.find('.owl-item.active').length - 1;
   
           var start = sync2.find('.owl-item.active').first().index();
   
           var end = sync2.find('.owl-item.active').last().index();
   
   
   
           if (current > end) {
   
               sync2.data('owl.carousel').to(current, 100, true);
   
           }
   
           if (current < start) {
   
               sync2.data('owl.carousel').to(current - onscreen, 100, true);
   
           }
   
       }
   
   
   
       function syncPosition2(el) {
   
           if (syncedSecondary) {
   
               var number = el.item.index;
   
               sync1.data('owl.carousel').to(number, 100, true);
   
           }
   
       }
   
   
   
       sync2.on("click", ".owl-item", function(e) {
   
           e.preventDefault();
   
           var number = $(this).index();
   
           sync1.data('owl.carousel').to(number, 300, true);
   
       });
   
   });
   
       
   
      
   
       
   
</script> 
</body>
</html>
