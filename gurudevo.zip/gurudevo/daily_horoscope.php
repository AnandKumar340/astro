<?php
session_start();
error_reporting(0);
include('db/conn.php');
?>
<?php include 'header.php' ?>
<div class="clearfix"></div>
<!-- DAILY HOROSCOPE -->
<div class="daily-horoscope">
   <div cLass="container">
   <?php
                           
                           if (isset($_GET['id'])) {
                              $id = $_GET['id'];
                              $sql = "select * from horoscope where id=".$id;
                              $result = mysqli_query($conn, $sql);
                              if (mysqli_num_rows($result) > 0) {
                                 $row = mysqli_fetch_assoc($result);
                              }else {
                                 $errorMsg = 'Could not Find Any Record';
                              }
                           }
                           ?>
               <?php $sql=mysqli_query($con,"select * from horoscope where id='$id'");
                                                while($row=mysqli_fetch_array($sql))
                                                {
                                                    ?>


      <h3>Free <span>Daily Horoscope <?php echo $row['title'] ?> </span></h3>
      <h4><?php echo $row['dt'] ?></h4>
                                                <?php } ?>

      <br>

      <div class="row">
         <div  class="col-sm-12">
            <div class="horoscopr-box">
               <div class="row">
               <div class="col-md-3 col-sm-4">
                                 
                                 <ul class="nav nav-tabs tabs-left sideways">

                                 <?php $sql=mysqli_query($con,"select * from horoscope");
                                                while($row=mysqli_fetch_array($sql))
                                                {
                                                    ?>
                                         
                                          <li><a href="daily_horoscope.php?id=<?php echo htmlentities($row['id']);?>"><i class="flaticon-<?php echo $row['icon'] ?>"></i> <span class="horo"><?php echo $row['title'] ?></span> <span></span></a></li>

                                        
                                      <?php } ?>


                                 </ul>
                           </div>        
                  <div class="col-md-9 col-sm-8">
                  <?php $sql=mysqli_query($con,"select * from horoscope where id='$id'");
                                                while($row=mysqli_fetch_array($sql))
                                                {
                                                    ?>
                     <!-- Tab panes -->
                     <div class="tab-content text-center">
                    
                        <div class="tab-pane active" id="<?php echo $row['id'] ?>">
                           <div class="horo-bxb">
                           <h3>Profession</h3>
                           <?php echo $row['profession'] ?>
                           </div>
                           <div class="horo-bxb">
                           <h3>Luck</h3>
                           <?php echo $row['luck'] ?>
                           </div>
                           <div class="horo-bxb">
                           <h3>Emotion</h3>
                           <?php echo $row['emotion'] ?>
                           </div>
                           <div class="horo-bxb">
                           <h3>Health</h3>
                           <?php echo $row['health'] ?>
                           </div>
                           <div class="horo-bxb">
                           <h3>Love</h3>
                           <?php echo $row['love'] ?>
                           </div>
                           <div class="horo-bxb">
                           <h3>Travel</h3>
                           <?php echo $row['travel'] ?>
                           </div>
                    
                        </div>
                     </div>
                     <?php } ?>
                  </div>
                  <div class="clearfix"></div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
                        
<!-- End DAILY HOROSCOPE -->
              <?php include 'partners.php' ?>        
      <?php include 'experts.php' ?>                      

<?php include 'footer.php' ?>