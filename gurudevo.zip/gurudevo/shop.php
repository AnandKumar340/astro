<?php
session_start();
error_reporting(0);
include('db/conn.php');
$cid=intval($_GET['cid']);
if(isset($_GET['action']) && $_GET['action']=="add"){
	$id=intval($_GET['id']);
	if(isset($_SESSION['cart'][$id])){
		$_SESSION['cart'][$id]['quantity']++;
	}else{
		$sql_p="SELECT * FROM products WHERE id={$id}";
		$query_p=mysqli_query($con,$sql_p);
		if(mysqli_num_rows($query_p)!=0){
			$row_p=mysqli_fetch_array($query_p);
			$_SESSION['cart'][$row_p['id']]=array("quantity" => 1, "price" => $row_p['productPrice']);
				echo "<script>alert('Product has been added to the cart')</script>";
		echo "<script type='text/javascript'> document.location ='my-cart.php'; </script>";
		}else{
			$message="Product ID is invalid";
		}
	}
	
}
// COde for Wishlist
if(isset($_GET['pid']) && $_GET['action']=="wishlist" ){
	if(strlen($_SESSION['login'])==0)
    {   
header('location:login.php');
}
else
{
mysqli_query($con,"insert into wishlist(userId,productId) values('".$_SESSION['id']."','".$_GET['pid']."')");
echo "<script>alert('Product aaded in wishlist');</script>";
header('location:my-wishlist.php');

}
}
?>
 <?php include 'header.php' ?>   
 <div class="clearfix"></div>

             <!-- hs About Title Start -->

    <div class="innerpage-hero user-profile-bann" style="background-image : url'(images/background-shop.jpg)'">

         <div class="container">

             <div class="row">

                 <div class="innerpage-hero-content">

                     <p>Our Shop</p>

 

                     <h1>GURUDEVO</h1>

                 </div>

             </div>

         </div>

     </div>


            <!-- hs About Title End -->

            <!-- hs sidebar Start -->

            <div class="hs_blog_categories_main_wrapper shop-pages">

                <div class="container">

                            <div class="hs_blog_left_sidebar_main_wrapper">

                                <div class="row">

                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

                                        <div class="hs_shop_tabs_cont_sec_wrapper text-center">

                                            <div class="hs_about_heading_wrapper text-center">
                                                 <h2> OUR <span> CATEGORIES</span></h2>
                                                 <h4><span></span></h4>
                                             </div>
                                             

                                            <div class="tab-content">

                                                <div id="home" class="tab-pane fade in active">

                                                    <div class="row">
                                                    <?php $sql=mysqli_query($con,"select id,categoryName,image  from category");
                                                        while($row=mysqli_fetch_array($sql))
                                                        {
                                                            ?>
                                                       

                                                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                                            <div class="hs_shop_prodt_main_box">
                                                                <div class="hs_shop_prodt_img_wrapper category_img">
                                                                <img  src="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['image']);?>" alt="shop_product">

                                                                    <a href="shop_list.php?cid=<?php echo $row['id'];?>"  class="accordion-toggle collapsed">
                                                                    <?php echo $row['categoryName'];?>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <?php } ?>


                                                    </div>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

            </div>

            <!-- hs sidebar End -->


   <?php include 'partners.php' ?>        
      <?php include 'experts.php' ?>                          

   <?php include 'footer.php' ?>        