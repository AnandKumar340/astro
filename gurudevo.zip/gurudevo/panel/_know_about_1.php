<?php
include('header.php');
  include('../db/conn.php');
  $upload_dir = 'uploads/';

  if(isset($_GET['delete'])){
		$id = $_GET['delete'];
		$sql = "select * from contact_banner where id = ".$id;
		$result = mysqli_query($conn, $sql);
		if(mysqli_num_rows($result) > 0){
			$row = mysqli_fetch_assoc($result);
			$image = $row['image'];
			unlink($upload_dir.$image);
			$sql = "delete from know_about_2 where id=".$id;
			if(mysqli_query($conn, $sql)){
				header('location: _know_about_1.php');
			}
		}
	}
?>

 

       <!--  BEGIN CONTENT PART  -->
       <div id="content" class="main-content">
            <div class="container">
                <div class="page-header">
                    <div class="page-title">
                        <h3>Testimonial</h3>
                    </div>
                </div>
                                
                <div class="row">
                   

                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 layout-spacing">
                        <div class="statbox widget box box-shadow">
                            <div class="widget-header">
                                <div class="row">
                                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                        <h4>Client Listing</h4>
                                    </div>                                   
                                </div>
                            </div>
                            <div class="widget-content widget-content-area">
                                <div class="table-responsive mb-4">
                                    <table id="ecommerce-order-list" class="table table-hover table-bordered">
                                        <thead>
                                            <tr>
                                                <th class="checkbox-column"> Id </th>
                                                <th>Image</th>
                                                <th>Tittle</th>
                                                <th>Sub Tittle</th>
                                                <th>Tittle 2</th>
                                                <th>Content</th>
                                                <th class="align-center">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                                $sql = "select * from contact_banner";
                                                $result = mysqli_query($conn, $sql);
                                                        if(mysqli_num_rows($result)){
                                                            while($row = mysqli_fetch_assoc($result)){
                                            ?>
                                            <tr>
                                                <td class="checkbox-column"><?php echo $row['id'] ?></td>
                                                <td class="text-center">
                                                <a class="product-list-img" href="javascript: void(0);"><img src="<?php echo $upload_dir.$row['image'] ?>" alt="Home Banner"></a></td>
                                                <td><?php echo $row['title'] ?></td>
                                                <td><?php echo $row['sub_title'] ?></td>
                                                <td><?php echo $row['title_2'] ?></td>
                                                <td><?php echo $row['content'] ?></td>
                                                <td class="text-center">
                                                    <a href="update_contact_banner.php?id=<?php echo $row['id'] ?>" class="btn btn-info">Update </a>
                                                    <a href="_know_about_1.php?delete=<?php echo $row['id'] ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete this record?')"> Delet</a>
                                                </td>
                                          
                                            </tr>
                                            <?php
                              }
                            }
                          ?>
                          
                                
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

<?php
    $insert = false;

  require_once("../db/conn.php");
  $upload_dir = 'uploads/';
  if (isset($_POST['Submit'])) {
    $title = $_POST['title'];
    $sub_title = $_POST['sub_title'];
    $title_2 = $_POST['title_2'];
    $content = $_POST['content'];
  
        $imgName = $_FILES['image']['name'];
		$imgTmp = $_FILES['image']['tmp_name'];
		$imgSize = $_FILES['image']['size'];
    if(empty($title)){
			$errorMsg = 'Please input title';
		}elseif(empty($sub_title)){
            $errorMsg = 'Please input sub_title';
		}elseif(empty($title_2)){
            $errorMsg = 'Please input title_2';
		}elseif(empty($content)){
			$errorMsg = 'Please input content';	
		}else{
			$imgExt = strtolower(pathinfo($imgName, PATHINFO_EXTENSION));
			$allowExt  = array('jpeg', 'jpg', 'png', 'gif');
			$userPic = time().'_'.rand(1000,9999).'.'.$imgExt;
			if(in_array($imgExt, $allowExt)){
				if($imgSize < 5000000){
					move_uploaded_file($imgTmp ,$upload_dir.$userPic);
				}else{
					$errorMsg = 'Image too large';
				}
			}else{
				$errorMsg = 'Please select a valid image';
			}
		}
		if(!isset($errorMsg)){
			$sql = "insert into contact_banner(title, sub_title, title_2, content, image)
					values('".$title."', '".$sub_title."',  '".$title_2."',  '".$content."', '".$userPic."')";
			$result = mysqli_query($conn, $sql);
            if($result){ 
                $insert = true;
            }
            else{
                echo "The record was not inserted successfully because of this error ---> ". mysqli_error($conn);
            } 
		}
  }
  header("Location: _know_about_1.php");
?>
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 layout-spacing">
                        <div class="statbox widget box box-shadow">
                            <div class="widget-header">
                                <div class="row">
                                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                        <h4>Add / Manage About us </h4>
                                    </div>
                                </div>
                            </div>
                            <div class="widget-content widget-content-area add-manage-product-2">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="card card-default">
                                            <div class="card-heading"><h2 class="card-title"><span>OUR SATIESFIED CLIENTS</span></h2></div>
                                            <div class="card-body">
                                                <div class="card-body">
                                                    <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
                                                        <div class="form-group mb-4">
                                                            <div class="row">
                                                                <label class="col-md-4">Title :</label>
                                                                <div class="col-md-8">
                                                                    <input class="form-control" name="title" type="text">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group mb-4">
                                                            <div class="row">
                                                                <label class="col-md-4">sub Title :</label>
                                                                <div class="col-md-8">
                                                                    <input class="form-control" name="sub_title" type="text">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group mb-4">
                                                            <div class="row">
                                                                <label class="col-md-4">Title 2 :</label>
                                                                <div class="col-md-8">
                                                                    <input class="form-control" name="title_2" type="text">
                                                                </div>
                                                            </div>
                                                        </div>
                                                
                                                        <div class="form-group mb-4">
                                                            <div class="row">
                                                                <label class="col-md-4">Content :</label>
                                                                <div class="col-md-8">
                                                                    <textarea rows="4" cols="5" id="comment" name="content" class="form-control"></textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                        <div class="row">
                                                            <label class="col-md-4">Image :</label>
                                                            <div class="col-md-8">
                                                                <div class="mb-3">
                                                                    <div class="custom-file">
                                                                        <input type="file" class="form-control-file" name="image" id="file-input">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="align-center"> 
                                                        <input value="Submit" onclick="showmsg();" name="Submit" class="btn btn-primary" type="submit" onclick="popUP()">
                                                    </div>
                                                   
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> 
                                    
            </div>
        </div>
        <script>
		CKEDITOR.replace('comment');
	</script> 
        <!--  END CONTENT PART  -->
<?php include 'footer.php' ?>
