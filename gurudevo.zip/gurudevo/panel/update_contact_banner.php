<?php
include_once("header.php");
include_once("../db/conn.php");
 $upload_dir = 'uploads/';
  if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "select * from contact_us where id=".$id;
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
      $row = mysqli_fetch_assoc($result);
    }else {
      $errorMsg = 'Could not Find Any Record';
    }
  }
  if(isset($_POST['Submit'])){
        $title = $_POST['title'];
        $sub_title = $_POST['sub_title'];
        $title_2 = $_POST['title_2'];
        $content = $_POST['content'];
        $title_3 = $_POST['title_3'];
        $content_3 = $_POST['content_3'];
        $phone = $_POST['phone'];
        $email = $_POST['email'];
        $address = $_POST['address'];
        $map = $_POST['map'];
    
      
		$imgName = $_FILES['image']['name'];
		$imgTmp = $_FILES['image']['tmp_name'];
		$imgSize = $_FILES['image']['size'];
		if($imgName){
			$imgExt = strtolower(pathinfo($imgName, PATHINFO_EXTENSION));
			$allowExt  = array('jpeg', 'jpg', 'png', 'gif');
			$userPic = time().'_'.rand(1000,9999).'.'.$imgExt;
			if(in_array($imgExt, $allowExt)){
				if($imgSize < 5000000){
					// unlink($upload_dir.$row['image']);
					move_uploaded_file($imgTmp ,$upload_dir.$userPic);
				}else{
					$errorMsg = 'Image too large';
				}
			}else{
				$errorMsg = 'Please select a valid image';
			}
		}else{
			$userPic = $row['image'];
		}
		if(!isset($errorMsg)){
			$sql = "update contact_us
                                    set title = '".$title."',
                                        sub_title = '".$sub_title."',
                                        title_2 = '".$title_2."',
                                        content = '".$content."',
                                        title_3 = '".$title_3."',
                                        content_3 = '".$content_3."',
                                        phone = '".$phone."',
                                        email = '".$email."',
                                        address = '".$address."',
                                        map = '".$map."',
										image = '".$userPic."'
					where id=".$id;
			$result = mysqli_query($conn, $sql);
			if($result){
				$successMsg = 'New record updated successfully';
			}else{
				$errorMsg = 'Error '.mysqli_error($conn);
			}
		}
    }
    header("Location: contact_us.php");
?>
      <!--  BEGIN CONTENT PART  -->
      <div id="content" class="main-content">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 layout-spacing">
                        <div class="statbox widget box box-shadow">
                            <div class="widget-header">
                                <div class="row">
                                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                    </div>
                                </div>
                            </div>
                            <div class="widget-content widget-content-area add-manage-product-2">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="card card-default">
                                            <div class="card-heading"><h2 class="card-title"><span>Contact Section 1</span></h2></div>
                                            <div class="card-body">
                                                <div class="card-body">
                                                    <form class="form-horizontal" action="" id="contact-form" method="post" enctype="multipart/form-data">
                                                        <div class="form-group mb-4">
                                                            <div class="row">
                                                                <label class="col-md-2">Title :</label>
                                                                <div class="col-md-10">
                                                                    <input type="text" class="form-control" name="title" value="<?php echo $row['title']; ?>">

                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group mb-4">
                                                            <div class="row">
                                                                <label class="col-md-2">Sub Title :</label>
                                                                <div class="col-md-10">
                                                                    <input type="text" class="form-control" name="sub_title" value="<?php echo $row['sub_title']; ?>">

                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group mb-4">
                                                            <div class="row">
                                                            <label class="col-md-2">Image :</label>
                                                                <div class="col-md-10">
                                                                    <img src="uploads/<?=$row['image'];?>" width="100">
                                                                    <input type="file" class="form-control" name="image" value="">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group mb-4">
                                                            <div class="row">
                                                                <label class="col-md-2">Title 2 :</label>
                                                                <div class="col-md-10">
                                                                    <input type="text" class="form-control" name="title_2" value="<?php echo $row['title_2']; ?>">

                                                                </div>
                                                            </div>
                                                        </div>
                                                 
                                                 
                                                        <div class="form-group mb-4">
                                                            <div class="row">
                                                                <label class="col-md-2">Content :</label>
                                                                <div class="col-md-10">
                                                                <textarea class="form-control" id="comment" name="content" rows="3" placeholder="Your Content"><?php if($row) echo $row['content']; ?></textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group mb-4">
                                                            <div class="row">
                                                                <label class="col-md-2">Title 3 :</label>
                                                                <div class="col-md-10">
                                                                    <input type="text" class="form-control" name="title_3" value="<?php echo $row['title_3']; ?>">

                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group mb-4">
                                                            <div class="row">
                                                                <label class="col-md-2">Content 3:</label>
                                                                <div class="col-md-10">
                                                                <textarea class="form-control" id="comment_3" name="content_3" rows="3" placeholder="Your Content"><?php if($row) echo $row['content_3']; ?></textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group mb-4">
                                                            <div class="row">
                                                                <label class="col-md-2">Phone  :</label>
                                                                <div class="col-md-10">
                                                                <textarea class="form-control" id="phone" name="phone" rows="3" placeholder="Your Content"><?php if($row) echo $row['phone']; ?></textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group mb-4">
                                                            <div class="row">
                                                                <label class="col-md-2">Email :</label>
                                                                <div class="col-md-10">
                                                                <textarea class="form-control" id="email" name="email" rows="3" placeholder="Your Content"><?php if($row) echo $row['email']; ?></textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group mb-4">
                                                            <div class="row">
                                                                <label class="col-md-2">Address :</label>
                                                                <div class="col-md-10">
                                                                <textarea class="form-control" id="address" name="address" rows="3" placeholder="Your Content"><?php if($row) echo $row['address']; ?></textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group mb-4">
                                                            <div class="row">
                                                                <label class="col-md-2">Map :</label>
                                                                <div class="col-md-10">
                                                                <textarea class="form-control" name="map" rows="3" placeholder="Your Content"><?php if($row) echo $row['map']; ?></textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <div class="align-center"> 
                                                        <input value="Update" name="Submit" class="btn btn-primary" type="submit">

                                                    </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> 
                </div>

                </div>

    <script>
		CKEDITOR.replace('comment');
        CKEDITOR.replace('comment_3');
        CKEDITOR.replace('phone');
        CKEDITOR.replace('email');
        CKEDITOR.replace('address');
	</script>        
     <script>
     $(document).ready(function(){
  $('#contact-form').on('submit',function(e) {  //Don't foget to change the id form
  $.ajax({
      data:$(this).serialize(),
      type:'POST',
      success:function(data){
        console.log(data);
        //Success Message == 'Title', 'Message body', Last one leave as it is
	    swal("¡Success!", "Data Updated Successfully!", "success");
      },
      error:function(data){
        //Error Message == 'Title', 'Message body', Last one leave as it is
	    swal("Oops...", "Something went wrong :(", "error");
      }
    });
    e.preventDefault(); //This is to Avoid Page Refresh and Fire the Event "Click"
  });
});
 </script>   
<?php include_once("footer.php"); ?>
