<?php include 'header.php' ?>

    <div class="clearfix">

        

    </div>

   <div class="checkout cart">

    <div class="container">

        <h3><span>Cart</span> Details</h3>

        <div class="row">

        <div class="col-sm-12 col-md-9">

        

        <!-- start cart-box -->

        <div class="cart-box">

            <div class="title">

                <div class="row">

                    

                    <div class="col-sm-4 col-xs-4">Total Amount</div>

                    <div class="col-sm-4 col-xs-4">GST@18%</div>

                    <div class="col-sm-4 col-xs-4">Total Payable Amount</div>

                </div>

            </div>

            <div class="cart-row">

                <div class="row">

                   

                    <div class="col-sm-4 col-xs-4"><i class="fa fa-rupee"></i> 100</div>

                    <div class="col-sm-4 col-xs-4"><i class="fa fa-rupee"></i> 18</div>

                    <div class="col-sm-4 col-xs-4"><i class="fa fa-rupee"></i> 118</div>



                </div>

                <div class="row" style="display: none;">

                    <div class="col-sm-12">

                        No Item in the Cart

                    </div>  

                </div>  

                                



            </div>

                        

                    </div>

        <!-- end cart-box -->

        </div>

        <div class="col-sm-12 col-md-3">

                <div class="rightcol-fixed">

                    <div class="add-coupon">

                        <h5 style="padding:0px;">Do you have referral code?</h5>

                        <span><i class="fa fa-rupee"></i>  5.00 cashback in wallet after recharge.</span>

                        <label>Enter the code below and click Apply</label>

                        <form method="post" action="#">

                            <div class="row">

                                <div class="col-md-8">

                                    <input type="text" class="form-control" name="code" id="code">

                                    

                                </div>

                                <div class="col-md-4 padding-left-none">

                                    <button class="btn btn-info btn-block">Apply</button>

                                </div>

                            </div>

                        </form>

                    </div>

                </div>

            </div>  

        </div>



        <div class="row">

            <div class="col-sm-6">

                <a href="shop.php" title="Continue Shopping" class="btn btn-info back-link"><i class="fa fa-chevron-circle-left" aria-hidden="true"></i> Continue Shopping</a>

            </div>

            

                            <div class="col-sm-6">

                    <a href="payment.php"><button title="Proceed to Checkout" class="btn btn-info pull-right">Proceed to Payment <i class="fa fa-chevron-circle-right" aria-hidden="true"></i> </button></a>

                </div>

                

        </div>

    </div>

</div>

    

    <?php include 'footer.php' ?>