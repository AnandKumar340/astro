<?php include 'header.php' ?>
<?php include 'db/conn.php' ?>
<?php

session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !==true)
{
    header("location: login.php");
}


?>
<a href="logout.php">Logout</a>

<?php include_once 'footer.php' ?>