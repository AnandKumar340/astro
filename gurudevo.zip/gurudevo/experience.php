<!-- hs Counter wrapper Start -->
<div class="hs_counter_main_wrapper">
<?php $sql=mysqli_query($con,"select * from experience");
                                                        while($row=mysqli_fetch_array($sql))
                                                        {
                                                            ?>
   <div class="hs_counter_cont_wrapper hs_counter_cont_wrapper1">
      <div class="count-description">
         <div class="hs_main_cycle_main">
            <span class="timer"><?php echo $row['number'] ?></span>
         </div>
         <h5 class="con1"><?php echo $row['title'] ?></h5>
      </div>
   </div>
   <?php  } ?>
</div>
<!-- hs Counter wrapper End -->