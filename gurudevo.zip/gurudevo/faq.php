<?php
session_start();
error_reporting(0);
include('db/conn.php');
?>
<title>Gurudevo Frequently Asked Questions</title>
<?php include 'header.php' ?>
<link rel='stylesheet' href='https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css'>
<style>
@import url('https://fonts.googleapis.com/css?family=Hind:300,400');
h2 {
  font-size: 1.8rem;
  color: #373d51;
  padding: 1.3rem;
  margin: 0;
}

.accordion a {
  position: relative;
  display: -webkit-box;
  display: -webkit-flex;
  display: flex;
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
  -webkit-flex-direction: column;
  flex-direction: column;
  width: 100%;
  padding: 1rem 3rem 1rem 1rem;
  color: #7288a2;
  font-size: 1.15rem;
  font-weight: 400;
  border-bottom: 1px solid #e5e5e5;
}

.accordion a:hover,
.accordion a:hover::after {
  cursor: pointer;
  color: #ff8c00;
}

.accordion a:hover::after {
  border: 1px solid #ff8c00;
}

.accordion a.active {
  color: #ff8c00;
  border-bottom: 1px solid #ff8c00;
}

.accordion a::after {
  font-family: 'Ionicons';
  content: '\f2c7';
  position: absolute;
  float: right;
  right: 1rem;
  font-size: 1rem;
  color: #7288a2;
  padding: 3px;
  width: 30px;
  height: 30px;
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  border-radius: 50%;
  border: 1px solid #7288a2;
  text-align: center;
}

.accordion a.active::after {
  font-family: 'Ionicons';
  content: '\f209';
  color: #ff8c00;
  border: 1px solid #ff8c00;
}

.accordion .content {
  display: none;
  padding: 1rem;
  border-bottom: 1px solid #ff8c00;
  overflow: hidden;
}

.accordion .content p {
  font-size: 1rem;
  font-weight: 300;
}
</style>
<div class="clearfix"></div>
<?php $sql=mysqli_query($con,"select * from faq");
            while($row=mysqli_fetch_array($sql)) {  ?>
<div class="container">
  <h2>Frequently Asked Questions</h2>

  <div class="accordion">
    <div class="accordion-item">
      <a> # <?php echo $row['title_1'] ?></a>
      <div class="content">
        <p><?php echo $row['content_1'] ?></p>
      </div>
    </div>

    <div class="accordion-item">
      <a> # <?php echo $row['title_2'] ?></a>
      <div class="content">
        <p><?php echo $row['content_2'] ?></p>
      </div>
    </div>
    <div class="accordion-item">
      <a> # <?php echo $row['title_3'] ?></a>
      <div class="content">
        <p><?php echo $row['content_2'] ?></p>
      </div>
    </div>
    <div class="accordion-item">
      <a> # <?php echo $row['title_4'] ?></a>
      <div class="content">
        <p><?php echo $row['content_4'] ?></p>
      </div>
    </div>
    <div class="accordion-item">
      <a> # <?php echo $row['title_5'] ?></a>
      <div class="content">
        <p><?php echo $row['content_5'] ?></p>
      </div>
    </div>
  </div>
  
</div>
            <?php } ?>
            
            
<script>
    $(document).ready(function() {
  $('.accordion a').click(function(){
    $(this).toggleClass('active');
    $(this).next('.content').slideToggle(400);
   });
});
</script>
<?php include 'footer.php' ?>