<div class="hs_online_main_slider_wrapper">
   <div class="container">
      <div class="row">
         <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
            <div class="hs_online_slider_left_cont">
               <h2>speak to <span>our expert !</span></h2>
               <p>Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum.</p>
            </div>
         </div>
         <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
            <div class="hs_online_slider_wrapper">
               <div class="owl-carousel owl-theme">
               <?php $sql=mysqli_query($con,"select * from experts");
                                                        while($row=mysqli_fetch_array($sql))
                                                        {
                                                            ?>
                                      <div class="item">
                                          <div class="hs_online_img_wrapper">
                                          <img src="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['image']);?>" alt="Our Experts">
                                             <span></span>
                                          </div>
                                       </div>
                                         

                                        
                                      <?php
                                          }
                                       
                                    ?>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>