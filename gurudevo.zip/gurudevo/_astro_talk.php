<?php
session_start();
error_reporting(0);
include('db/conn.php');
?>
<!-- hs Navigation End -->
<div class="clearfix"></div>

<!-- ASTROLOGY SERVICES -->
<div class="astrologies-services">
   <div class="container">
      <div class="row">
         <div class="col-lg-12">
            <div class="hs_about_heading_wrapper text-center">
               <h2>TALK TO <span> ASTROLOGERS</span></h2>
               <h4><span></span></h4>
               <p>Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum<br> auctor, nisi elit consequat hello Aenean world.</p>
            </div>
         </div>
      </div>
      <div class="row">
         <?php $sql=mysqli_query($con,"select * from astro_service");
                                                while($row=mysqli_fetch_array($sql))
                                                {
                                                    ?>
         <div class="col-lg-3 col-sm-6 col-md-6"  >
            <div class="card-container" >
               <div class="card" >
                  <div class="front " >
                     <div class="cover">
                        <img src="images/astro-img/Kundali.jpg"/>
                     </div>
                     <div class="user">
                        <img  class="img-circle" src="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['image']);?>" alt="Product Image">


                     </div>
                     <div class="content">
                        <div class="main">
                           <h3 class="name"><?php echo $row['title'] ?></h3>
                           <p class="profession"><?php echo $row['sub_title'] ?></p>
                           <p class="text-center"><?php echo $row['content'] ?></p>
                        </div>
                     </div>
                  </div>
                  <!-- end front panel -->
                  <div class="back">
                     <div class="header">
                        <h5 class="motto">"<?php echo $row['title_2'] ?>"</h5>
                     </div>
                     <div class="content">
                        <div class="main">
                        <button type="button" class="btn btn-primary"> <h4><a href="" data-toggle="modal" data-target="#<?php echo $row['id'] ?>"> Join Us </a></h4> </button>

                           <div class="stats-container ">
                           
                           </div>
                        </div>
                     </div>
                        <div class="footer">
                           <div class="social-links text-center">
                              <a href="http://gurudevo.in/talk_to_astro.php" class="facebook" id="<?php echo $row['id'] ?>" ><i class="fa fa-facebook fa-fw"></i></a>
                              <a target="_blank" href="https://web.whatsapp.com/send?text=http://gurudevo.in/talk_to_astro.php" data-original-title="whatsapp" rel="tooltip" data-placement="left" data-action="share/whatsapp/share"><i class="fa  fa-whatsapp"></i></a>
                              <!-- <a class="fb-share" href="https://www.instagram.com?url=http://gurudevo.in/talk_to_astro.php" target="_blank" rel="noopener"><i class="social_facebook"></i> <i class="fa fa-instagram"></i></a> -->
                              <a href="https://www.instagram.com/?url=http://gurudevo.in/talk_to_astro.php/" target="_blank" rel="noopener"><i class="fa fa-instagram"></i> </a>

                           </div>
                        </div>
                        <!-- api for facebook  -->
                        <script>
                                var facebookShare = document.querySelector('[id="<?php echo $row['id'] ?>"]');

                                 facebookShare.onclick = function(e) {
                                 e.preventDefault();
                                 var facebookWindow = window.open('https://www.facebook.com/sharer/sharer.php?u=' + document.URL, 'facebook-popup', 'height=350,width=600');
                                 if(facebookWindow.focus) { facebookWindow.focus(); }
                                    return false;
                                 }
                        </script>
                                                <!-- /api for facebook  -->
                                               


                     </div>
                     <!-- end back panel -->
                  </div>
                  <!-- end card -->
               </div>
               <!-- end card-container -->
            </div>
         <?php } ?>

      </div>
   </div>
</div>
<!-- start service form using php  -->


<?php $sql=mysqli_query($con,"select * from astro_service");
                                                while($row=mysqli_fetch_array($sql))
                                                { ?>
<!-- Modal -->
<div class="modal fade" id="<?php echo $row['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
   <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <div class="modal-body">
            <div class="row">
               <div class="col-md-5">
                  <div class="modal-txt-left">

                     <h3>Welcome Back</h3>
                     <p>To keep connected with us Please Login with your personal info</p>
                  </div>
               </div>
                     <div class="col-md-7">
                        <div class="form">
                           <div class="tab-content wallets">
                                 <h1>Talk to Gurudevo's Astrologers</h1>
                                 <p class="small-txt">To keep connected with us Please Sign Up with your personal info </p>
                              <div class="row">
                                 <div class="col-md-12">
                                    <div class="tab-content male-female wallets-pops">
                                       <form action="mail.php" method="post" enctype="multipart/form-data">
                                       <div class="row">

                                       <div class="col-md-6">
                                       <div class="form-group">
                                       <label>
                                       Your Service area <span class="req"></span>
                                       </label>
                                       <input type="text" name="title"  value="<?php echo $row['title'] ?>" readonly>
                                       </div>
                                       </div>

                                       <div class="col-md-6">
                                       <div class="form-group">
                                       <label>
                                       Name<span class="req">*</span>
                                       </label>
                                       <input type="text" name="name" placeholder="Full Name" required>
                                       </div>
                                       </div>

                                       <div class="col-md-6">
                                       <div class="form-group">
                                       <label>
                                       Email<span class="req">*</span>
                                       </label>
                                       <input type="email" name="email" placeholder="Enter Email" required>
                                       </div>
                                       </div>

                                       <div class="col-md-6">
                                       <div class="form-group">
                                       <label>
                                       Mobile Number<span class="req">*</span>
                                       </label>
                                       <input type="number" name="phone" placeholder="Mobile Number" required>
                                       </div>
                                       </div>

                                       <div class="col-md-6">
                                       <div class="form-group">
                                       <label>
                                       Gender<span class="req">*</span>
                                       </label>
                                       <ul class="radio-btn row">
                                       <li class="col-md-6"><input class="radio-check" type="radio" name="gender" id="male" value="Male" required>
                                       <label class="gender"> Male </label></li>
                                       <li class="col-md-6"><input class="radio-check" type="radio" name="gender" id="female" value="Female" required>
                                       <label class="gender"> Female </label></li>
                                       </ul>
                                       </div>   
                                       </div>

                                       <div class="col-md-6">
                                       <div class="form-group">
                                       <label>
                                       DOB<span class="req">*</span>
                                       </label>
                                       <input type="date" name="dob" required>
                                       </div>
                                       </div>

                                       <div class="col-md-6">
                                       <div class="form-group">
                                       <label>
                                       Time of Birth<span class="req">*</span>
                                       </label>
                                       <input type="time" class="tob" name="tob" required>
                                       </div>
                                       </div>

                                       <div class="col-md-6">
                                       <div class="form-group">
                                       <label>
                                       Place of Birth<span class="req" name="place">*</span>
                                       </label>
                                       <input type="text" autocomplete="off" placeholder="Ex - Delhi" name="place" required>
                                       </div>
                                       </div>

                                       <div class="col-md-12">
                                       <div class="form-group">
                                       <label>
                                       Picture of Both Hand<span class="req" name="pob"></span>
                                       </label>
                                       <input type="file" name="file_image">
                                       </div>
                                       </div>
                                 
                                       <div class="col-md-12">
                                       <ul class="tab-group">
                                       <li class="tab"><button type="submit" name="submit" class="btn"> Submit</button></li>
                                       </ul>
                                       </div>
                                       </div>
                                       </form>
                                    </div>
                                 </div>
                              </div><!-- tab-content -->
                           </div><!-- /form -->
                        </div>
                     </div>
                  </div>
               </div>
            </div> <!-- /row -->
         </div>
      </div>
   </div>
</div>
<!-- End Modal  -->
         <?php } ?>


<script>
   $('.time').timepicker();
</script>
<!--main js file end-->

<?php $sql=mysqli_query($con,"select * from astro_service");
                                                while($row=mysqli_fetch_array($sql))
                                                {
                                                    ?>
<script>
     $(document).ready(function(){
  $('#service-form<?php echo $row['id'];?>').on('submit',function(e) {  //Don't foget to change the id form
  $.ajax({
      data:$(this).serialize(),
      type:'POST',
      success:function(data){
        console.log(data);
        //Success Message == 'Title', 'Message body', Last one leave as it is
	    swal("Success !", "<a href='package_wallet_money.php?id=<?php echo $row['id'];?>' class='service-alert text-success'>Click Here To Recharge your Wallet</a>", "success");
      },
      error:function(data){
        //Error Message == 'Title', 'Message body', Last one leave as it is
	    swal("Oops...", "Something went wrong :(", "error");
      }
    });
    e.preventDefault(); //This is to Avoid Page Refresh and Fire the Event "Click"
  });
});
 </script>


 <?php } ?>
