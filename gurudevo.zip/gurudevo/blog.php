<?php
session_start();
error_reporting(0);
include('db/conn.php');
?>
<?php include 'header.php' ?>
<!-- hs title wrapper Start -->
<div class="clearfix"></div>
<div class="blog-area">
   <div class="container">
      <div class="row">
      <?php $sql=mysqli_query($con,"select * from blog");
                                                        while($row=mysqli_fetch_array($sql))
                                                        {
                                                            ?>
         <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 blog">
            <div class="blog-content">
               <div class="image">
                  <img src="panel/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['image']);?>">
               </div>
               <div class="hs_title_img_cont_wrapper">
                  <h2><a href="blog_detail.php?id=<?php echo $row['id'] ?>"><?php echo $row['title'] ?></a></h2>
                  <p><?php echo $row['sub_title'] ?></p>
                  <p><?php echo $row['author'] ?></p>
                  <p><?php echo $row['date_time'] ?></p>
                  <h5><a href="blog_detail.php?id=<?php echo $row['id'] ?>">Read More <i class="fa fa-long-arrow-right"></i></a></h5>
               </div>
            </div>
         </div>
         <?php }  ?>
        
      </div>
   </div>
</div>
<!-- hs title wrapper End -->
<?php include 'footer.php' ?>