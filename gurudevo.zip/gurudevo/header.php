  <!DOCTYPE html>
  <html>
  <head>
      <title>Gurudevo</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- style -->
     <link rel="stylesheet" type="text/css" href="css/animate.css" />
     <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
     <link rel="stylesheet" type="text/css" href="css/font-awesome.css" />
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     <link rel="stylesheet" type="text/css" href="css/fonts.css" />
     <link rel="stylesheet" type="text/css" href="font/flaticon.css" />
     <link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css" />
     <link rel="stylesheet" type="text/css" href="css/owl.theme.default.min.css" />
     <link rel="stylesheet" type="text/css" href="css/magnific-popup.css" />
     <link rel="stylesheet" type="text/css" href="css/reset.css" />
     <link rel="stylesheet" type="text/css" href="css/style.css" />
     <link rel="stylesheet" type="text/css" href="css/responsive.css" />

       <link href="css/rotating-card.css" rel="stylesheet" />
     <!-- favicon links -->
     <link rel="shortcut icon" type="image/png" href="images/favicon.ico" />

     <!-- SWEET ALERT CDN  -->
     <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
     <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.js"></script>
     <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.css">
     <!-- SWEET ALERT CDN  -->

 </head>
 
 <body>
     <!-- preloader Start -->
     <div id="preloader">
         <div id="status"><img src="images/om.gif" id="preloader_image" alt="loader">
         </div>
     </div>
     <!-- hs top header Start -->
     <div class="hs_top_header_main_Wrapper">
         <div class="container">
             <div class="hs_header_logo_left hidden-xs">
                 <div class="hs_logo_wrapper">
                     <a href="index.php"><img src="images/logo2.png" class="img-responsive" alt="logo" title="Logo"/></a>
                 </div>
             </div>
             <div class="hs_header_logo_center hidden-xs">
                 <div class="hs_text_wrapper">
                     <h3>गुरु ब्रह्मा, गुरु विष्णु गुरु देवो महेश्वर, गुरु साक्षात् परमं ब्रह्मा तस्मै श्री गुरुवे नम:</h3>
                    
                 </div>
             </div>
             <div class="hs_header_logo_right">
                 <div class="hs_btn_wrapper">
                     <ul>
                         <li><a href="talk_to_astro.php" class="hs_btn_hover">Talk to Astrologers</a></li>

                     </ul>
                 </div>
                 <a href="my-cart.php" class="hs_btn_hover"> <i class="fa fa-cart-plus"></i> </a>
              
             </div>
         </div>
     </div>
     <!-- hs top header End -->
     <!-- hs Navigation Start -->
     <div class="hs_navigation_header_wrapper">
         <div class="container">
             <div class="row">
                 <div class="col-lg-6 col-md-6 col-sm-7 col-xs-12">
                     <nav class="hs_main_menu hidden-xs">
                         <ul>
                             <li>
                                 <div class="dropdown-wrapper menu-button">
                                     <a class="menu-button" href="index.php">Home</a>
                                     <div class="drop-menu">
                                                                              </div>
                                 </div>
                             </li>
                             <li>
                                 <a class="menu-button" href="talk_to_astro.php">Talk to Astrologers</a>
                             </li>
                             <li>
                                 <a class="menu-button" href="about_us.php">About Us</a>
                             </li>
                            
                             <li>
                                 <div class="dropdown-wrapper menu-button">
                                     <a class="menu-button" href="shop.php">Shop</a>
                                     <div class="drop-menu">
                                        
                                         <!--<a class="menu-button" href="#">Shop-Single</a>-->
                                     </div>
                                 </div>
                             </li>
                           <li>
                                 <a class="menu-button" href="blog.php">Blog </a>
                             </li>
                             <li>
                                 <a class="menu-button" href="contact_us.php">Contact </a>
                             </li>
                         </ul>
                     </nav>
                     <header class="mobail_menu visible-xs">
                         <div class="container-fluid">
                             <div class="row">
                                 <div class="col-xs-6 col-sm-6">
                                     <div class="hs_logo">
                                         <a href="index.php"><img src="images/logo2.png" alt="Logo" title="Logo"></a>
                                     </div>
                                 </div>
                                 <div class="col-xs-6 col-sm-6">
                                     <div class="cd-dropdown-wrapper">
                                         <a class="house_toggle" href="#0">
                                                     <i class="fa fa-navicon"></i>
                                                     </a>
                                         <nav class="cd-dropdown">
                                             <img src="images/logo2.png">
                                             <a href="#0" class="cd-close">Close</a>
                                             <ul class="cd-dropdown-content">
                                                 <li>
                                                 <form name="search" method="post" action="search-result.php">
                                                        <div class="control-group">
                                                            <input class="search-field" placeholder="Search here..." name="product" required="required" />
                                                            <button class="search-button" type="submit" name="search"><i class="fa fa-search"></i></button>    
                                                        </div>
                                                    </form>
                                                 </li>
                                               
                                                  <li>
                                                     <a href="talk_to_astro.php">Talk to Astrology</a>
                                                 </li>
                                                  <li>
                                                     <a href="about_us.php">About US</a>
                                                 </li>
                                                 <!-- .has-children -->
 
                                                 
                                                 <!-- .has-children -->
                                                 <li class="">
                                                     <a href="shop.php">Shop</a>
 
                                                
                                                 </li>
                                                 <!-- .has-children -->
                                                 <li>
                                                     <a href="blog.php">Blog</a>

                                                 </li>
                                                 <!-- .has-children -->
                                                 <li>
                                                     <a href="contact_us.php">Contact</a>
                                                 </li>
                                                 <li>
                                                 <?php if(strlen($_SESSION['login'])==0)
                                                        {   ?>
                                                        <a class="menu-button" href="login.php" style="color: #fff;"><i class="fa fa-user"></i> Login</a>
                                                            <?php }
                                                        else{ ?>
                                
                                                            <a class="menu-button" href="logout.php" style="color: #fff;"><i class="fa fa-user"></i> Logout</a>

                                                        <?php } ?>
                                                        <?php if(strlen($_SESSION['login']))
                                                    {   ?>
                                                        <a href="my-account.php" class="menu-button"><i class="icon fa fa-user"></i> Welcome - <?php echo htmlentities($_SESSION['username']);?></a>
                                                        <?php } ?>
                                                 </li>
 
                                             </ul>
                                             <!-- .cd-dropdown-content -->
 
 
 
                                         </nav>
                                         <!-- .cd-dropdown -->
 
                                     </div>
                                 </div>
                             </div>
                         </div>
                         <!-- .cd-dropdown-wrapper -->
                     </header>
                 </div>
                 <div class="col-lg-6 col-md-6 col-sm-5 col-xs-12 hidden-xs">
                     <div class="hs_navi_searchbar_wrapper">
                     <form name="search" method="post" action="search-result.php">
                        <div class="control-group">
                            <input class="search-field" placeholder="Search here..." name="product" required="required" />
                            <button class="search-button" type="submit" name="search"><i class="fa fa-search"></i></button>    
                        </div>
				    </form>
                     </div>

                    <div class="hs_navi_cart_wrapper">
                         <div class="dropdown-wrapper menu-button">
                         <?php if(strlen($_SESSION['login'])==0)
                            {   ?>
                             <a class="menu-button" href="login.php" style="color: #fff;"><i class="fa fa-user"></i> Login</a>
                                <?php }
                            else{ ?>
	
                                <a class="menu-button" href="logout.php" style="color: #fff;"><i class="fa fa-user"></i> Logout</a>

				            <?php } ?>
                            <?php if(strlen($_SESSION['login']))
                        {   ?>
                            <a href="my-account.php" class="menu-button"><i class="icon fa fa-user"></i>Welcome - <?php echo htmlentities($_SESSION['username']);?></a>
                            <?php } ?>
                             
                         </div>
                     </div> 
                 </div>
             </div>
         </div>
     </div>
     <!-- hs Navigation End -->