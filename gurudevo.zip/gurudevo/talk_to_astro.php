<?php
session_start();
error_reporting(0);
include('db/conn.php');
?>
<?php include 'header.php' ?>
<?php include '_astro_talk.php' ?>
<?php include 'footer.php' ?>
